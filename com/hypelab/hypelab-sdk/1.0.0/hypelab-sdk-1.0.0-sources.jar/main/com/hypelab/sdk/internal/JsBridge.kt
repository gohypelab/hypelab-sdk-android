package com.hypelab.sdk.internal

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.TelephonyManager
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.google.android.gms.appset.AppSet
import com.google.android.gms.appset.AppSetIdInfo
import com.hypelab.sdk.HypeLab
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * JavaScript bridge for OTA bundle communication.
 *
 * Note: Context stored here is ApplicationContext, which is safe.
 */
@SuppressLint("StaticFieldLeak")
internal class JsBridge(
    private val context: Context,
    private val webView: WebView
) {
    companion object {
        private const val TAG = "HypeLab"
        private const val PREFS_NAME = "hypelab_storage"
        private const val SECURE_PREFS_NAME = "hypelab_secure_storage"
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO)

    // Regular storage for non-sensitive data
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // Encrypted storage for sensitive data like device ID (PRD Section 4.1.1)
    private val securePrefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                SECURE_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed to create encrypted prefs, falling back to regular: ${e.message}")
            prefs  // Fallback to regular prefs if encryption fails
        }
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Banner renderers keyed by placement ID
    private val bannerRenderers = mutableMapOf<String, BannerRenderer>()

    // =========================================================================
    // Lifecycle
    // =========================================================================

    @JavascriptInterface
    fun onBundleReady(version: String) {
        mainHandler.post { SdkCore.onBundleReady(version) }
    }

    // =========================================================================
    // Banner Events (called by JS)
    // =========================================================================

    @JavascriptInterface
    fun onBannerLoaded(placementId: String, width: Int, height: Int, adm: String, refreshIntervalMs: Long) {
        val interval = if (refreshIntervalMs > 0) refreshIntervalMs else null
        mainHandler.post { SdkCore.onBannerLoaded(placementId, width, height, adm, interval) }
    }

    @JavascriptInterface
    fun onBannerError(placementId: String, error: String) {
        mainHandler.post { SdkCore.onBannerError(placementId, error) }
    }

    @JavascriptInterface
    fun onBannerImpression(placementId: String) {
        mainHandler.post { SdkCore.onBannerImpression(placementId) }
    }

    @JavascriptInterface
    fun onBannerClick(placementId: String) {
        mainHandler.post { SdkCore.onBannerClick(placementId) }
    }

    // =========================================================================
    // Native Ad Events (called by JS)
    // =========================================================================

    @JavascriptInterface
    fun onNativeLoaded(placementId: String, assetsJson: String) {
        mainHandler.post { SdkCore.onNativeLoaded(placementId, assetsJson) }
    }

    @JavascriptInterface
    fun onNativeError(placementId: String, error: String) {
        mainHandler.post { SdkCore.onNativeError(placementId, error) }
    }

    // =========================================================================
    // Interstitial Ad Events (called by JS)
    // =========================================================================

    @JavascriptInterface
    fun onInterstitialLoaded(placementId: String, adDataJson: String) {
        mainHandler.post { SdkCore.onInterstitialLoaded(placementId, adDataJson) }
    }

    @JavascriptInterface
    fun onInterstitialError(placementId: String, error: String) {
        mainHandler.post { SdkCore.onInterstitialError(placementId, error) }
    }

    // =========================================================================
    // Rewarded Ad Events (called by JS)
    // =========================================================================

    @JavascriptInterface
    fun onRewardedLoaded(placementId: String, adDataJson: String) {
        mainHandler.post { SdkCore.onRewardedLoaded(placementId, adDataJson) }
    }

    @JavascriptInterface
    fun onRewardedError(placementId: String, error: String) {
        mainHandler.post { SdkCore.onRewardedError(placementId, error) }
    }

    // =========================================================================
    // Banner Rendering
    // =========================================================================

    fun createBannerRenderer(placementId: String, width: Int, height: Int): BannerRenderer {
        val renderer = BannerRenderer(context, mainHandler, width, height)
        bannerRenderers[placementId] = renderer
        return renderer
    }

    fun getBannerRenderer(placementId: String): BannerRenderer? = bannerRenderers[placementId]

    fun destroyBannerRenderer(placementId: String) {
        bannerRenderers.remove(placementId)?.destroy()
    }

    // =========================================================================
    // Device Info (PRD Section 4.1.2)
    // =========================================================================

    @JavascriptInterface
    fun getDeviceInfo(callbackId: String) {
        val displayMetrics = context.resources.displayMetrics
        val density = displayMetrics.density
        val dpr = maxOf(1, minOf(3, Math.round(density).toInt()))

        // Get carrier info (MCC/MNC)
        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val carrier = telephonyManager?.networkOperator?.takeIf { it.length >= 5 }?.let {
            "${it.substring(0, 3)}-${it.substring(3)}"  // Format as "MCC-MNC"
        }

        val info = JSONObject().apply {
            put("manufacturer", Build.MANUFACTURER)
            put("model", Build.MODEL)
            put("osVersion", Build.VERSION.RELEASE)
            put("sdkInt", Build.VERSION.SDK_INT)
            put("density", density.toDouble())
            put("dpr", dpr)
            put("screenWidthPx", displayMetrics.widthPixels)
            put("screenHeightPx", displayMetrics.heightPixels)
            // Additional signals per PRD Section 4.1.2
            put("timezone", TimeZone.getDefault().id)
            put("locale", context.resources.configuration.locales[0].toString())
            put("carrier", carrier ?: "")
            put("cores", Runtime.getRuntime().availableProcessors())
        }

        resolveCallback(callbackId, true, info.toString())
    }

    // =========================================================================
    // Advertising ID (GAID) - PRD Section 4.1
    // =========================================================================

    /**
     * Get the Google Advertising ID (GAID) if available.
     * Returns the GAID and limit ad tracking status.
     * PRD Section 4.1: "Android: GAID — Collected unless opted out"
     */
    @JavascriptInterface
    fun getAdvertisingId(callbackId: String) {
        scope.launch {
            try {
                val adInfo = AdvertisingIdClient.getAdvertisingIdInfo(context)
                val isLimitAdTracking = adInfo.isLimitAdTrackingEnabled
                val result = JSONObject().apply {
                    // Only include GAID if user hasn't opted out
                    put("id", if (isLimitAdTracking) "" else (adInfo.id ?: ""))
                    put("lmt", if (isLimitAdTracking) 1 else 0)
                }
                resolveCallback(callbackId, true, result.toString())
            } catch (e: Exception) {
                // GAID may be unavailable (e.g., no Google Play Services)
                Log.w(TAG, "GAID unavailable: ${e.message}")
                val result = JSONObject().apply {
                    put("id", "")
                    put("lmt", 0)
                }
                resolveCallback(callbackId, true, result.toString())
            }
        }
    }

    // =========================================================================
    // App Set ID - PRD Section 4.1
    // =========================================================================

    /**
     * Get the App Set ID if available.
     * Returns the App Set ID and scope (APP or DEVELOPER).
     * PRD Section 4.1: "Android: App Set ID — Privacy-preserving alternative, scoped to developer account"
     *
     * App Set ID is:
     * - Privacy-preserving (scoped to developer account, not device-wide)
     * - Always available (doesn't require user opt-in like GAID)
     * - Survives app reinstalls
     * - Resets when user uninstalls ALL apps from the same developer
     */
    @JavascriptInterface
    fun getAppSetId(callbackId: String) {
        scope.launch {
            try {
                val client = AppSet.getClient(context)
                val taskResult = com.google.android.gms.tasks.Tasks.await(client.appSetIdInfo)
                val result = JSONObject().apply {
                    put("id", taskResult.id)
                    // Scope: SCOPE_APP (1) or SCOPE_DEVELOPER (2)
                    put("scope", when (taskResult.scope) {
                        AppSetIdInfo.SCOPE_APP -> "app"
                        AppSetIdInfo.SCOPE_DEVELOPER -> "developer"
                        else -> "unknown"
                    })
                }
                resolveCallback(callbackId, true, result.toString())
            } catch (e: Exception) {
                // App Set ID may be unavailable (e.g., old Google Play Services)
                Log.w(TAG, "App Set ID unavailable: ${e.message}")
                val result = JSONObject().apply {
                    put("id", "")
                    put("scope", "unknown")
                }
                resolveCallback(callbackId, true, result.toString())
            }
        }
    }

    // =========================================================================
    // Storage
    // =========================================================================

    @JavascriptInterface
    fun storageGet(key: String, callbackId: String) {
        val value = prefs.getString(key, null)
        if (value != null) {
            resolveCallback(callbackId, true, value)
        } else {
            resolveCallback(callbackId, false, "Key not found")
        }
    }

    @JavascriptInterface
    fun storageSet(key: String, value: String, callbackId: String) {
        try {
            prefs.edit().putString(key, value).apply()
            resolveCallback(callbackId, true, "OK")
        } catch (e: Exception) {
            resolveCallback(callbackId, false, "Storage error: ${e.message}")
        }
    }

    // =========================================================================
    // Secure Storage (for sensitive data like device ID - PRD Section 4.1.1)
    // =========================================================================

    @JavascriptInterface
    fun secureStorageGet(key: String, callbackId: String) {
        try {
            val value = securePrefs.getString(key, null)
            if (value != null) {
                resolveCallback(callbackId, true, value)
            } else {
                resolveCallback(callbackId, false, "Key not found")
            }
        } catch (e: Exception) {
            resolveCallback(callbackId, false, "Secure storage error: ${e.message}")
        }
    }

    @JavascriptInterface
    fun secureStorageSet(key: String, value: String, callbackId: String) {
        try {
            securePrefs.edit().putString(key, value).apply()
            resolveCallback(callbackId, true, "OK")
        } catch (e: Exception) {
            resolveCallback(callbackId, false, "Secure storage error: ${e.message}")
        }
    }

    /**
     * Get or create the HypeLab Device ID.
     * This is stored in encrypted storage and persists across reinstalls (with backup).
     */
    @JavascriptInterface
    fun getHypeLabDeviceId(callbackId: String) {
        try {
            val existingId = securePrefs.getString("hypelab_device_id", null)
            if (existingId != null) {
                resolveCallback(callbackId, true, existingId)
            } else {
                // Generate new UUID and store it
                val newId = java.util.UUID.randomUUID().toString()
                securePrefs.edit().putString("hypelab_device_id", newId).apply()
                resolveCallback(callbackId, true, newId)
            }
        } catch (e: Exception) {
            // Fallback to regular prefs if secure storage fails
            val existingId = prefs.getString("hypelab_device_id", null)
            if (existingId != null) {
                resolveCallback(callbackId, true, existingId)
            } else {
                val newId = java.util.UUID.randomUUID().toString()
                prefs.edit().putString("hypelab_device_id", newId).apply()
                resolveCallback(callbackId, true, newId)
            }
        }
    }

    // =========================================================================
    // Network
    // =========================================================================

    @JavascriptInterface
    fun networkFetch(url: String, optionsJson: String, callbackId: String) {
        scope.launch {
            try {
                val options = JSONObject(optionsJson)
                val method = options.optString("method", "GET")
                val bodyStr = options.optString("body", null)

                // Debug logging - only when debug mode is enabled
                if (HypeLab.isInitialized && HypeLab.config.debug) {
                    Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                    Log.d(TAG, "REQUEST: $method $url")
                    Log.d(TAG, "HEADERS: ${options.optJSONObject("headers")}")
                    Log.d(TAG, "BODY: $bodyStr")
                    Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                }

                val requestBody = if (bodyStr != null && method in listOf("POST", "PUT", "PATCH")) {
                    val contentType = options.optJSONObject("headers")
                        ?.optString("Content-Type", "application/json")
                        ?: "application/json"
                    bodyStr.toRequestBody(contentType.toMediaType())
                } else null

                val requestBuilder = Request.Builder().url(url)

                when (method) {
                    "GET" -> requestBuilder.get()
                    "POST" -> requestBuilder.post(requestBody ?: "".toRequestBody(null))
                    "PUT" -> requestBuilder.put(requestBody ?: "".toRequestBody(null))
                    "PATCH" -> requestBuilder.patch(requestBody ?: "".toRequestBody(null))
                    "DELETE" -> requestBuilder.delete(requestBody)
                    else -> requestBuilder.method(method, requestBody)
                }

                options.optJSONObject("headers")?.let { headers ->
                    headers.keys().forEach { key ->
                        requestBuilder.addHeader(key, headers.getString(key))
                    }
                }

                val response = httpClient.newCall(requestBuilder.build()).execute()
                val responseBody = response.body?.string() ?: ""

                // Debug logging - only when debug mode is enabled
                if (HypeLab.isInitialized && HypeLab.config.debug) {
                    Log.d(TAG, "RESPONSE: ${response.code} ${response.message}")
                    Log.d(TAG, "RESPONSE BODY: $responseBody")
                    Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                }

                if (response.isSuccessful) {
                    resolveCallback(callbackId, true, responseBody)
                } else {
                    resolveCallback(callbackId, false, "HTTP ${response.code}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Network error: ${e.message}", e)
                resolveCallback(callbackId, false, "Network error: ${e.message}")
            }
        }
    }

    // =========================================================================
    // Tracking
    // =========================================================================

    @JavascriptInterface
    fun trackingFire(url: String, callbackId: String) {
        scope.launch {
            var lastError: Exception? = null

            repeat(3) { attempt ->
                try {
                    val request = Request.Builder().url(url).get().build()
                    val response = httpClient.newCall(request).execute()
                    if (response.isSuccessful) {
                        resolveCallback(callbackId, true, "OK")
                        return@launch
                    }
                    lastError = Exception("HTTP ${response.code}")
                } catch (e: Exception) {
                    lastError = e
                }
                if (attempt < 2) delay(1000L * (attempt + 1))
            }

            resolveCallback(callbackId, false, "Tracking failed: ${lastError?.message}")
        }
    }

    // =========================================================================
    // SDK Settings (for JS bundle to build RTB request)
    // =========================================================================

    @JavascriptInterface
    fun getSdkSettings(callbackId: String) {
        try {
            val privacy = HypeLab.getPrivacySettings()

            // Read IAB US Privacy String (PRD Section 5.3)
            // Standard location per IAB CCPA Framework
            val usPrivacyString = context.getSharedPreferences("IABUSPrivacy", Context.MODE_PRIVATE)
                .getString("IABUSPrivacy_String", null)

            // Read GPP String (PRD Section 5 - Global Privacy Platform)
            // Standard location per IAB GPP Framework
            val iabPrefs = context.getSharedPreferences("IABTCF_", Context.MODE_PRIVATE)
            val gppString = iabPrefs.getString("IABGPP_HDR_GppString", null)
            val gppSid = iabPrefs.getString("IABGPP_GppSID", null)

            val settings = JSONObject().apply {
                // Test mode
                put("testMode", HypeLab.isTestMode)

                // Device ID
                put("deviceId", HypeLab.deviceID)

                // Wallet addresses
                put("walletAddresses", org.json.JSONArray(HypeLab.walletAddresses))

                // Privacy settings (PRD Section 5)
                put("gdprConsent", privacy.gdprConsent)
                put("coppa", privacy.childDirectedTreatment)
                put("tfua", privacy.underAgeOfConsent)
                put("rdp", privacy.restrictedDataProcessing)

                // TCF v2.2 consent strings (PRD Section 5.1)
                privacy.tcfConsentString?.let { put("tcString", it) }
                privacy.tcfAdditionalConsent?.let { put("addtlConsent", it) }
                privacy.tcfGdprApplies?.let { put("tcfGdprApplies", it) }

                // CCPA/US Privacy (PRD Section 5.3)
                usPrivacyString?.let { put("usPrivacyString", it) }

                // GPP (Global Privacy Platform)
                gppString?.let { put("gppString", it) }
                gppSid?.let { put("gppSid", it) }
            }
            resolveCallback(callbackId, true, settings.toString())
        } catch (e: Exception) {
            resolveCallback(callbackId, false, "Failed to get SDK settings: ${e.message}")
        }
    }

    // =========================================================================
    // Logging
    // =========================================================================

    @JavascriptInterface
    fun log(level: String, message: String) {
        when (level.lowercase()) {
            "debug", "d" -> Log.d(TAG, "[JS] $message")
            "info", "i" -> Log.i(TAG, "[JS] $message")
            "warn", "w" -> Log.w(TAG, "[JS] $message")
            "error", "e" -> Log.e(TAG, "[JS] $message")
            else -> Log.v(TAG, "[JS] $message")
        }
    }

    // =========================================================================
    // Internal
    // =========================================================================

    private fun resolveCallback(callbackId: String, success: Boolean, data: String) {
        val escapedData = data
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")

        val js = "window.__hypelab_resolve_callback(\"$callbackId\", $success, \"$escapedData\");"

        mainHandler.post {
            webView.evaluateJavascript(js, null)
        }
    }
}
