package com.hypelab.sdk.internal

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.hypelab.sdk.HypeLab
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Manages OTA bundle downloads, verification, and caching.
 *
 * PRD Section 9: OTA Updates
 * - ECDSA signature verification
 * - Crash detection: revert after 3 consecutive crashes
 * - Minimum native version enforcement
 * - Gradual rollout support
 * - Fallback to bundled asset on failure
 *
 * Bundle lifecycle:
 * 1. Check manifest API for updates
 * 2. Download bundle from CDN if update available
 * 3. Verify hash and signature before storing
 * 4. Cache verified bundle to internal storage
 * 5. Track crashes per version - rollback after 3
 * 6. Fall back to bundled asset if verification fails
 */
internal class BundleManager(
    private val context: Context,
    private val config: HypeLab.Config
) {
    companion object {
        private const val TAG = "HypeLab"
        private const val MAX_CRASH_COUNT = 3
        private const val PREFS_NAME = "hypelab_bundle_prefs"
        private const val KEY_CURRENT_VERSION = "current_bundle_version"
        private const val KEY_CRASH_COUNT = "bundle_crash_count"
        private const val KEY_CRASHED_VERSION = "bundle_crashed_version"
        private const val BUNDLE_FILENAME = "bundle.js"
        private const val FALLBACK_BUNDLE_ASSET = "bundle.js"
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val cacheDir: File = File(context.filesDir, "hypelab_bundles").apply {
        if (!exists()) mkdirs()
    }

    /**
     * Manifest data returned by the API.
     */
    data class BundleManifest(
        val version: String,
        val hash: String,
        val signature: String,
        val minNativeVersion: String?,
        val rolloutPercentage: Int,
        val killed: Boolean,
        val bundleUrl: String,
        val publicKeys: List<PublicKeyInfo>
    ) {
        data class PublicKeyInfo(val keyId: String, val publicKey: String)

        companion object {
            fun fromJson(json: JSONObject): BundleManifest? {
                // Check if no update available
                if (!json.optBoolean("update_available", true) && !json.has("version")) {
                    return null
                }

                val publicKeysArray = json.optJSONArray("public_keys")
                val publicKeys = mutableListOf<PublicKeyInfo>()
                if (publicKeysArray != null) {
                    for (i in 0 until publicKeysArray.length()) {
                        val keyObj = publicKeysArray.getJSONObject(i)
                        publicKeys.add(PublicKeyInfo(
                            keyId = keyObj.getString("key_id"),
                            publicKey = keyObj.getString("public_key")
                        ))
                    }
                }

                return BundleManifest(
                    version = json.getString("version"),
                    hash = json.getString("hash"),
                    signature = json.getString("signature"),
                    minNativeVersion = json.optString("min_native_version", null),
                    rolloutPercentage = json.optInt("rollout_percentage", 100),
                    killed = json.optBoolean("killed", false),
                    bundleUrl = json.getString("bundle_url"),
                    publicKeys = publicKeys
                )
            }
        }
    }

    /**
     * Load the best available bundle.
     * Returns the JavaScript content as a string, or null if unavailable.
     *
     * Priority order:
     * 1. Cached OTA bundle (if not killed, not over crash limit)
     * 2. New OTA bundle from CDN (if available and passes verification)
     * 3. Bundled fallback asset
     */
    suspend fun loadBundle(): String? = withContext(Dispatchers.IO) {
        Log.i(TAG, "=== BundleManager.loadBundle() START ===")
        try {
            // Record app start for crash detection
            Log.d(TAG, "BundleManager: Recording app start for crash detection...")
            recordAppStart()

            // Initialize verifier with embedded key
            Log.d(TAG, "BundleManager: Initializing BundleVerifier...")
            BundleVerifier.initialize(context)
            Log.d(TAG, "BundleManager: BundleVerifier initialized, trusted keys: ${BundleVerifier.trustedKeyCount()}")

            // Try to fetch manifest and download new bundle
            Log.d(TAG, "BundleManager: Fetching manifest from API...")
            val manifest = fetchManifest()

            if (manifest != null) {
                Log.i(TAG, "BundleManager: Manifest received!")
                Log.d(TAG, "  - version: ${manifest.version}")
                Log.d(TAG, "  - hash: ${manifest.hash.take(16)}...")
                Log.d(TAG, "  - signature: ${manifest.signature.take(20)}...")
                Log.d(TAG, "  - bundleUrl: ${manifest.bundleUrl}")
                Log.d(TAG, "  - minNativeVersion: ${manifest.minNativeVersion}")
                Log.d(TAG, "  - rolloutPercentage: ${manifest.rolloutPercentage}")
                Log.d(TAG, "  - killed: ${manifest.killed}")
                Log.d(TAG, "  - publicKeys: ${manifest.publicKeys.size} keys")

                // Add API-provided keys for verification
                manifest.publicKeys.forEach { key ->
                    Log.d(TAG, "BundleManager: Adding trusted key from API: ${key.keyId}")
                    BundleVerifier.addTrustedKey(key.keyId, key.publicKey)
                }
                Log.d(TAG, "BundleManager: Total trusted keys after adding API keys: ${BundleVerifier.trustedKeyCount()}")

                // Check if we should download this version
                Log.d(TAG, "BundleManager: Checking if we should download this version...")
                if (shouldDownload(manifest)) {
                    Log.d(TAG, "BundleManager: Should download = true, downloading and verifying...")
                    val newBundle = downloadAndVerify(manifest)
                    if (newBundle != null) {
                        Log.i(TAG, "BundleManager: Bundle downloaded and verified successfully!")
                        saveBundle(newBundle, manifest.version)
                        resetCrashCount(manifest.version)
                        Log.i(TAG, "=== BundleManager.loadBundle() END (OTA bundle) ===")
                        return@withContext newBundle
                    } else {
                        Log.w(TAG, "BundleManager: Download/verification failed, trying cached or fallback")
                    }
                } else {
                    Log.d(TAG, "BundleManager: Should download = false (already have version or other reason)")
                }
            } else {
                Log.w(TAG, "BundleManager: No manifest available (API returned null or no update)")
            }

            // Try cached bundle
            Log.d(TAG, "BundleManager: Trying cached bundle...")
            val cached = loadCachedBundle()
            if (cached != null) {
                Log.i(TAG, "BundleManager: Using cached bundle v${getCurrentVersion()} (${cached.length} chars)")
                Log.i(TAG, "=== BundleManager.loadBundle() END (cached bundle) ===")
                return@withContext cached
            } else {
                Log.d(TAG, "BundleManager: No cached bundle available")
            }

            // Fall back to bundled asset
            Log.d(TAG, "BundleManager: Trying fallback bundled asset...")
            val fallback = loadFallbackBundle()
            if (fallback != null) {
                Log.i(TAG, "BundleManager: Using fallback bundled asset (${fallback.length} chars)")
            } else {
                Log.e(TAG, "BundleManager: No fallback bundle available!")
            }
            Log.i(TAG, "=== BundleManager.loadBundle() END (fallback bundle) ===")
            return@withContext fallback

        } catch (e: Exception) {
            Log.e(TAG, "BundleManager: Exception during bundle load: ${e.message}", e)
            // Last resort: try fallback
            val fallback = loadFallbackBundle()
            Log.i(TAG, "=== BundleManager.loadBundle() END (exception, fallback=${fallback != null}) ===")
            return@withContext fallback
        }
    }

    /**
     * Fetch the bundle manifest from the API.
     */
    private fun fetchManifest(): BundleManifest? {
        Log.d(TAG, "fetchManifest: Starting...")
        try {
            val baseUrl = config.rtbEndpoint.substringBeforeLast("/v1/")
            val url = buildString {
                append("$baseUrl/v1/sdk/manifest")
                append("?device_id=${HypeLab.deviceID}")
                append("&native_version=${HypeLab.VERSION}")
                append("&current_version=${getCurrentVersion() ?: ""}")
            }

            Log.i(TAG, "fetchManifest: URL = $url")

            val request = Request.Builder().url(url).build()
            Log.d(TAG, "fetchManifest: Executing HTTP request...")

            val response = httpClient.newCall(request).execute()
            Log.d(TAG, "fetchManifest: HTTP response code = ${response.code}")

            if (!response.isSuccessful) {
                Log.e(TAG, "fetchManifest: HTTP error ${response.code}")
                val errorBody = response.body?.string()
                Log.e(TAG, "fetchManifest: Error response body: ${errorBody?.take(500)}")
                return null
            }

            val body = response.body?.string()
            if (body == null) {
                Log.e(TAG, "fetchManifest: Response body is null")
                return null
            }

            Log.d(TAG, "fetchManifest: Response body (${body.length} chars): ${body.take(500)}")

            val json = JSONObject(body)
            Log.d(TAG, "fetchManifest: Parsed JSON successfully")

            val manifest = BundleManifest.fromJson(json)
            if (manifest != null) {
                Log.i(TAG, "fetchManifest: Manifest parsed successfully")
            } else {
                Log.w(TAG, "fetchManifest: No update available (manifest is null)")
            }
            return manifest
        } catch (e: Exception) {
            Log.e(TAG, "fetchManifest: Exception: ${e.message}", e)
            return null
        }
    }

    /**
     * Check if we should download the manifest version.
     */
    private fun shouldDownload(manifest: BundleManifest): Boolean {
        // Don't download if killed
        if (manifest.killed) {
            if (config.debug) {
                Log.d(TAG, "Bundle v${manifest.version} is killed")
            }
            return false
        }

        // Check min native version compatibility
        manifest.minNativeVersion?.let { minVersion ->
            if (!isCompatibleVersion(HypeLab.VERSION, minVersion)) {
                if (config.debug) {
                    Log.d(TAG, "Bundle v${manifest.version} requires native v$minVersion")
                }
                return false
            }
        }

        // Already have this version
        if (manifest.version == getCurrentVersion()) {
            return false
        }

        // Check crash count for this version
        if (getCrashCount(manifest.version) >= MAX_CRASH_COUNT) {
            if (config.debug) {
                Log.d(TAG, "Bundle v${manifest.version} exceeded crash limit")
            }
            return false
        }

        return true
    }

    /**
     * Download bundle from CDN and verify hash + signature.
     * Returns the bundle content if valid, null otherwise.
     */
    private fun downloadAndVerify(manifest: BundleManifest): String? {
        Log.d(TAG, "downloadAndVerify: Starting for v${manifest.version}")
        try {
            Log.d(TAG, "downloadAndVerify: Bundle URL = ${manifest.bundleUrl}")

            val request = Request.Builder().url(manifest.bundleUrl).build()
            Log.d(TAG, "downloadAndVerify: Executing HTTP request...")

            val response = httpClient.newCall(request).execute()
            Log.d(TAG, "downloadAndVerify: HTTP response code = ${response.code}")

            if (!response.isSuccessful) {
                Log.e(TAG, "downloadAndVerify: HTTP error ${response.code}")
                val errorBody = response.body?.string()
                Log.e(TAG, "downloadAndVerify: Error response: ${errorBody?.take(500)}")
                return null
            }

            val bundleBytes = response.body?.bytes()
            if (bundleBytes == null) {
                Log.e(TAG, "downloadAndVerify: Response body is null")
                return null
            }

            Log.d(TAG, "downloadAndVerify: Downloaded ${bundleBytes.size} bytes")

            // Verify hash
            Log.d(TAG, "downloadAndVerify: Verifying hash...")
            val actualHash = BundleVerifier.computeHash(bundleBytes)
            Log.d(TAG, "downloadAndVerify: Expected hash = ${manifest.hash}")
            Log.d(TAG, "downloadAndVerify: Actual hash   = $actualHash")

            if (!BundleVerifier.verifyHash(bundleBytes, manifest.hash)) {
                Log.e(TAG, "downloadAndVerify: HASH MISMATCH!")
                return null
            }
            Log.i(TAG, "downloadAndVerify: Hash verified OK")

            // Verify signature
            Log.d(TAG, "downloadAndVerify: Verifying signature...")
            Log.d(TAG, "downloadAndVerify: Signature (first 50 chars) = ${manifest.signature.take(50)}")
            Log.d(TAG, "downloadAndVerify: Trusted keys count = ${BundleVerifier.trustedKeyCount()}")

            if (!BundleVerifier.verify(bundleBytes, manifest.signature)) {
                Log.e(TAG, "downloadAndVerify: SIGNATURE VERIFICATION FAILED!")
                return null
            }
            Log.i(TAG, "downloadAndVerify: Signature verified OK")

            Log.i(TAG, "downloadAndVerify: Bundle v${manifest.version} verified successfully!")
            return String(bundleBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            Log.e(TAG, "downloadAndVerify: Exception: ${e.message}", e)
            return null
        }
    }

    /**
     * Save verified bundle to internal storage.
     */
    private fun saveBundle(content: String, version: String) {
        try {
            val bundleFile = File(cacheDir, BUNDLE_FILENAME)
            bundleFile.writeText(content)

            prefs.edit()
                .putString(KEY_CURRENT_VERSION, version)
                .apply()

            if (config.debug) {
                Log.d(TAG, "Bundle v$version saved to cache")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save bundle: ${e.message}")
        }
    }

    /**
     * Load cached bundle from internal storage.
     */
    private fun loadCachedBundle(): String? {
        return try {
            val bundleFile = File(cacheDir, BUNDLE_FILENAME)
            if (bundleFile.exists()) {
                val version = getCurrentVersion()

                // Check crash count
                if (version != null && getCrashCount(version) >= MAX_CRASH_COUNT) {
                    if (config.debug) {
                        Log.d(TAG, "Cached bundle v$version exceeded crash limit, using fallback")
                    }
                    return null
                }

                bundleFile.readText()
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load cached bundle: ${e.message}")
            null
        }
    }

    /**
     * Load fallback bundle from bundled assets.
     */
    private fun loadFallbackBundle(): String? {
        return try {
            context.assets.open(FALLBACK_BUNDLE_ASSET).bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load fallback bundle: ${e.message}")
            null
        }
    }

    /**
     * Get currently installed bundle version.
     */
    private fun getCurrentVersion(): String? {
        return prefs.getString(KEY_CURRENT_VERSION, null)
    }

    // =========================================================================
    // Crash Detection (PRD Section 9)
    // =========================================================================

    /**
     * Record that the app has started with the current bundle.
     * If the app crashed last time, increment crash count.
     */
    private fun recordAppStart() {
        val crashedVersion = prefs.getString(KEY_CRASHED_VERSION, null)

        if (crashedVersion != null) {
            // App crashed last time - increment crash count
            val currentCount = prefs.getInt("${KEY_CRASH_COUNT}_$crashedVersion", 0)
            prefs.edit()
                .putInt("${KEY_CRASH_COUNT}_$crashedVersion", currentCount + 1)
                .remove(KEY_CRASHED_VERSION)
                .apply()

            if (config.debug) {
                Log.w(TAG, "Bundle v$crashedVersion crash count: ${currentCount + 1}")
            }
        }

        // Mark current version as potentially crashing
        getCurrentVersion()?.let { version ->
            prefs.edit()
                .putString(KEY_CRASHED_VERSION, version)
                .apply()
        }
    }

    /**
     * Mark the bundle as successfully loaded (clear crash marker).
     * Call this after WebView successfully executes the bundle.
     */
    fun markBundleHealthy() {
        prefs.edit()
            .remove(KEY_CRASHED_VERSION)
            .apply()

        if (config.debug) {
            Log.d(TAG, "Bundle marked as healthy")
        }
    }

    /**
     * Get crash count for a specific version.
     */
    private fun getCrashCount(version: String): Int {
        return prefs.getInt("${KEY_CRASH_COUNT}_$version", 0)
    }

    /**
     * Reset crash count for a version (called after successful download).
     */
    private fun resetCrashCount(version: String) {
        prefs.edit()
            .putInt("${KEY_CRASH_COUNT}_$version", 0)
            .apply()
    }

    // =========================================================================
    // Version Comparison
    // =========================================================================

    /**
     * Check if current native version is compatible with minimum required.
     * Uses semantic versioning comparison.
     */
    private fun isCompatibleVersion(current: String, minimum: String): Boolean {
        return try {
            val currentParts = current.split(".").map { it.toIntOrNull() ?: 0 }
            val minimumParts = minimum.split(".").map { it.toIntOrNull() ?: 0 }

            for (i in 0 until maxOf(currentParts.size, minimumParts.size)) {
                val currentPart = currentParts.getOrElse(i) { 0 }
                val minimumPart = minimumParts.getOrElse(i) { 0 }

                when {
                    currentPart > minimumPart -> return true
                    currentPart < minimumPart -> return false
                }
            }
            true // Versions are equal
        } catch (e: Exception) {
            Log.w(TAG, "Version comparison error: ${e.message}")
            true // Allow on error
        }
    }

    /**
     * Clear all cached bundles. Used for testing/debugging.
     */
    fun clearCache() {
        cacheDir.listFiles()?.forEach { it.delete() }
        prefs.edit()
            .remove(KEY_CURRENT_VERSION)
            .remove(KEY_CRASHED_VERSION)
            .apply()

        if (config.debug) {
            Log.d(TAG, "Bundle cache cleared")
        }
    }
}
