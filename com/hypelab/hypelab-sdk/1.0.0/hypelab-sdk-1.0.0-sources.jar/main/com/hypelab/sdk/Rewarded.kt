package com.hypelab.sdk

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.hypelab.sdk.internal.FullscreenActivity
import com.hypelab.sdk.internal.SdkCore
import java.util.UUID

/**
 * Rewarded ad unit.
 *
 * Full-screen ads that reward users after watching a video or
 * completing an engagement action.
 *
 * Usage:
 * ```kotlin
 * val rewarded = Rewarded("your-placement-slug")
 *
 * rewarded.onReady = { Log.d("Ad", "Rewarded ready") }
 * rewarded.onError = { error -> Log.e("Ad", "Error: $error") }
 * rewarded.onReward = { reward ->
 *     Log.d("Ad", "Reward earned: ${reward.amount} ${reward.type}")
 *     grantRewardToUser(reward)
 * }
 * rewarded.onClose = { Log.d("Ad", "Closed") }
 *
 * rewarded.loadAd()
 *
 * // When ready, show at user request (e.g., "Watch ad for coins")
 * if (rewarded.isReady) {
 *     rewarded.show()
 * }
 * ```
 */
class Rewarded(val placementSlug: String) {
    internal val placementId: String = UUID.randomUUID().toString()

    private val mainHandler = Handler(Looper.getMainLooper())

    // State machine
    private var state: State = State.IDLE

    // Cached ad data (unified format from JS bundle)
    internal var adData: FullscreenAdData? = null
        private set

    // Ad expiration (PRD: 1 hour TTL)
    private var loadedAtTime: Long? = null
    private var expirationRunnable: Runnable? = null

    // Reward tracking
    private var rewardEarned = false

    // =========================================================================
    // Public Callbacks (PRD Section 3.4)
    // =========================================================================

    /** Called when ad is loaded and ready to show */
    var onReady: (() -> Unit)? = null

    /** Called when an error occurs */
    var onError: ((HypeLabError) -> Unit)? = null

    /** Called when ad is displayed and impression is tracked */
    var onImpression: (() -> Unit)? = null

    /** Called when user clicks the ad */
    var onClick: (() -> Unit)? = null

    /** Called when video starts playing */
    var onVideoStart: (() -> Unit)? = null

    /** Called when video completes (user watched entire video) */
    var onVideoComplete: (() -> Unit)? = null

    /** Called when video playback encounters an error */
    var onVideoError: ((String) -> Unit)? = null

    /** Called when user earns the reward - CRITICAL: Grant reward here */
    var onReward: ((Reward) -> Unit)? = null

    /** Called when ad is closed (regardless of reward status) */
    var onClose: (() -> Unit)? = null

    /** Called when loaded ad expires (older than 1 hour) */
    var onExpired: (() -> Unit)? = null

    // =========================================================================
    // Public Properties
    // =========================================================================

    /** Returns true when an ad is loaded, ready to display, and not expired */
    val isReady: Boolean get() = state == State.LOADED && !isExpired

    /** Returns true if the loaded ad has expired */
    val isExpired: Boolean get() {
        val loaded = loadedAtTime ?: return false
        return System.currentTimeMillis() - loaded > AD_TTL_MS
    }

    /** Returns true if the rewarded ad is currently being displayed */
    val isShowing: Boolean
        get() = when (state) {
            State.SHOWING, State.VIDEO_PLAYING, State.DISPLAY_ENGAGED -> true
            else -> false
        }

    /** Returns true if an ad load is currently in progress */
    val isLoading: Boolean get() = state == State.LOADING

    /** Returns true if the user has earned the reward in current session */
    val hasEarnedReward: Boolean get() = rewardEarned

    // =========================================================================
    // SSV (Server-Side Verification)
    // =========================================================================

    /**
     * Optional SSV options for server-to-server reward verification.
     * Set before calling loadAd() if you want SSV data included in the ad request.
     */
    var ssvOptions: SSVOptions? = null

    // =========================================================================
    // Lifecycle Methods
    // =========================================================================

    init {
        if (!HypeLab.isInitialized) {
            Log.e(TAG, "SDK not initialized. Call HypeLab.initialize() first.")
        }
        SdkCore.registerRewarded(this)
    }

    /**
     * Load a rewarded ad. Call this before showing.
     * Recommended: Load early to ensure ad is ready when user wants to watch.
     */
    fun loadAd() {
        if (!HypeLab.isInitialized) {
            onError?.invoke(HypeLabError.NotInitialized())
            return
        }

        if (state == State.LOADING) {
            onError?.invoke(HypeLabError.LoadInProgress())
            return
        }

        // Reset state for reload
        adData = null
        loadedAtTime = null
        rewardEarned = false

        state = State.LOADING
        log("Loading rewarded ad...")

        SdkCore.loadRewardedAd(this) { result ->
            result.onFailure { error ->
                state = State.ERROR
                mainHandler.post {
                    onError?.invoke(error as? HypeLabError ?: HypeLabError.InternalError(error.message ?: "Unknown"))
                }
            }
        }
    }

    /**
     * Show the rewarded ad.
     * Must be called after ad is loaded (check `isReady` first).
     */
    fun show() {
        if (!HypeLab.isInitialized) {
            onError?.invoke(HypeLabError.NotInitialized())
            return
        }

        if (!isReady) {
            val error = when (state) {
                State.SHOWING, State.VIDEO_PLAYING -> HypeLabError.AdAlreadyShowing()
                else -> if (isExpired) HypeLabError.AdExpired() else HypeLabError.InternalError("Ad not ready. Call loadAd() first.")
            }
            onError?.invoke(error)
            return
        }

        val context = SdkCore.getContext()
        if (context == null) {
            onError?.invoke(HypeLabError.InternalError("Context unavailable"))
            return
        }

        state = State.SHOWING
        log("Showing rewarded ad...")

        // Data is already in FullscreenAdData format and cached by SdkCore.onRewardedLoaded()
        // Just launch the unified full-screen Activity
        val intent = Intent(context, FullscreenActivity::class.java).apply {
            putExtra(FullscreenActivity.EXTRA_PLACEMENT_ID, placementId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * Cancel any in-progress ad load.
     * Use this to abandon an ad flow without destroying the ad unit.
     * The rewarded ad can be reused by calling loadAd() again.
     */
    fun cancel() {
        if (state != State.LOADING) {
            log("Cancel called but not loading (state=$state)")
            return
        }

        log("Cancelling load")
        stopExpirationTimer()
        SdkCore.cancelRewardedLoad(placementId)
        adData = null
        loadedAtTime = null
        rewardEarned = false
        state = State.IDLE
    }

    /**
     * Destroy the rewarded ad and release resources.
     */
    fun destroy() {
        log("Destroying")
        stopExpirationTimer()

        SdkCore.destroyRewardedInJs(placementId)
        SdkCore.unregisterRewarded(placementId)

        adData = null

        // Clear callbacks
        onReady = null
        onError = null
        onImpression = null
        onClick = null
        onVideoStart = null
        onVideoComplete = null
        onVideoError = null
        onReward = null
        onClose = null
        onExpired = null

        state = State.IDLE
    }

    // =========================================================================
    // Internal Callbacks (called by SdkCore/FullscreenActivity)
    // =========================================================================

    internal fun _onAdLoaded(data: FullscreenAdData) {
        adData = data
        loadedAtTime = System.currentTimeMillis()

        mainHandler.post {
            state = State.LOADED
            log("Rewarded ready: ${data.creativeType}, reward=${data.reward}")
            onReady?.invoke()
            startExpirationTimer()
        }
    }

    internal fun _onAdError(error: HypeLabError) {
        state = State.ERROR
        mainHandler.post {
            log("Rewarded error: ${error.message}")
            onError?.invoke(error)
        }
    }

    internal fun _onImpression() {
        mainHandler.post {
            log("Impression")
            onImpression?.invoke()
        }
    }

    internal fun _onClick() {
        mainHandler.post {
            log("Click")
            onClick?.invoke()
        }
    }

    internal fun _onVideoStart() {
        state = State.VIDEO_PLAYING
        mainHandler.post {
            log("Video started")
            onVideoStart?.invoke()
        }
    }

    internal fun _onVideoComplete() {
        mainHandler.post {
            log("Video complete")
            onVideoComplete?.invoke()
        }
    }

    internal fun _onVideoError(errorMessage: String) {
        mainHandler.post {
            log("Video error: $errorMessage")
            onVideoError?.invoke(errorMessage)
        }
    }

    /**
     * Called when reward should be granted.
     * For video: when video completes
     * For display: when engagement action is completed
     */
    internal fun _onReward() {
        if (rewardEarned) return // Prevent double-granting

        rewardEarned = true
        val reward = adData?.reward ?: Reward("reward", 1)

        mainHandler.post {
            log("Reward granted: $reward")
            onReward?.invoke(reward)
        }
    }

    internal fun _onClose() {
        mainHandler.post {
            log("Close (rewardEarned=$rewardEarned)")
            state = State.DISMISSED
            onClose?.invoke()
        }
    }

    // =========================================================================
    // Private Helpers
    // =========================================================================

    private fun startExpirationTimer() {
        stopExpirationTimer()
        expirationRunnable = Runnable {
            if (state == State.LOADED) {
                log("Ad expired")
                mainHandler.post { onExpired?.invoke() }
            }
        }
        mainHandler.postDelayed(expirationRunnable!!, AD_TTL_MS)
    }

    private fun stopExpirationTimer() {
        expirationRunnable?.let { mainHandler.removeCallbacks(it) }
        expirationRunnable = null
    }

    private fun log(message: String) {
        if (HypeLab.isInitialized && HypeLab.config.debug) {
            Log.d(TAG, "[Rewarded:$placementSlug] $message")
        }
    }

    private enum class State {
        IDLE,
        LOADING,
        LOADED,
        SHOWING,          // Transitioning to playback
        VIDEO_PLAYING,    // Video is playing
        DISPLAY_ENGAGED,  // Display ad, user engaging
        DISMISSED,
        ERROR
    }

    companion object {
        private const val TAG = "HypeLab"
        private const val AD_TTL_MS = 60 * 60 * 1000L  // 1 hour
    }
}
