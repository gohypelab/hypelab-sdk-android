package com.hypelab.sdk

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.hypelab.sdk.internal.FullscreenActivity
import com.hypelab.sdk.internal.SdkCore
import java.util.UUID

/**
 * Interstitial ad unit.
 *
 * Full-screen ads displayed at natural transition points
 * (level completion, app launch, between content screens).
 *
 * Usage:
 * ```kotlin
 * val interstitial = Interstitial("your-placement-slug")
 *
 * interstitial.onReady = { Log.d("Ad", "Interstitial ready") }
 * interstitial.onError = { error -> Log.e("Ad", "Error: $error") }
 * interstitial.onImpression = { Log.d("Ad", "Impression") }
 * interstitial.onClick = { Log.d("Ad", "Click") }
 * interstitial.onClose = { Log.d("Ad", "Closed") }
 *
 * interstitial.loadAd()
 *
 * // When ready, show at a natural break point
 * if (interstitial.isReady) {
 *     interstitial.show()
 * }
 * ```
 */
class Interstitial(val placementSlug: String) {
    internal val placementId: String = UUID.randomUUID().toString()

    private val mainHandler = Handler(Looper.getMainLooper())

    // State machine
    private var state: State = State.IDLE

    // Cached ad data (unified format from JS bundle)
    internal var adData: FullscreenAdData? = null
        private set

    // Ad expiration (PRD: 1 hour TTL)
    private var loadedAtTime: Long? = null
    private var expirationRunnable: Runnable? = null

    // Public callbacks (matching PRD Section 3.3)
    var onReady: (() -> Unit)? = null
    var onError: ((HypeLabError) -> Unit)? = null
    var onImpression: (() -> Unit)? = null
    var onClick: (() -> Unit)? = null
    var onClose: (() -> Unit)? = null
    var onExpired: (() -> Unit)? = null

    /**
     * Returns true when an ad is loaded, ready to display, and not expired.
     */
    val isReady: Boolean get() = state == State.LOADED && !isExpired

    /**
     * Returns true if the loaded ad has expired (older than 1 hour).
     */
    val isExpired: Boolean get() {
        val loaded = loadedAtTime ?: return false
        return System.currentTimeMillis() - loaded > AD_TTL_MS
    }

    /*
     * Returns true if the interstitial is currently being displayed.
     */
    val isShowing: Boolean get() = state == State.SHOWING

    /**
     * Returns true if an ad load is currently in progress.
     */
    val isLoading: Boolean get() = state == State.LOADING

    init {
        if (!HypeLab.isInitialized) {
            Log.e(TAG, "SDK not initialized. Call HypeLab.initialize() first.")
        }
        SdkCore.registerInterstitial(this)
    }

    /**
     * Load an ad. Call this before showing the interstitial.
     * Recommended: Load early (e.g., when user starts a level) to ensure
     * the ad is ready when needed.
     */
    fun loadAd() {
        if (!HypeLab.isInitialized) {
            onError?.invoke(HypeLabError.NotInitialized())
            return
        }

        if (state == State.LOADING) {
            onError?.invoke(HypeLabError.LoadInProgress())
            return
        }

        // Reset state for reload
        adData = null
        loadedAtTime = null

        state = State.LOADING
        log("Loading ad...")

        SdkCore.loadInterstitialAd(this) { result ->
            result.onFailure { error ->
                state = State.ERROR
                mainHandler.post {
                    onError?.invoke(error as? HypeLabError ?: HypeLabError.InternalError(error.message ?: "Unknown"))
                }
            }
            // onSuccess is handled via _onAdLoaded callback
        }
    }

    /**
     * Show the interstitial ad.
     *
     * Must be called after the ad is loaded (check `isReady` first).
     * Shows a full-screen Activity that renders the ad.
     *
     * @throws IllegalStateException if called when ad is not ready
     */
    fun show() {
        if (!HypeLab.isInitialized) {
            onError?.invoke(HypeLabError.NotInitialized())
            return
        }

        if (!isReady) {
            val error = when (state) {
                State.SHOWING -> HypeLabError.AdAlreadyShowing()
                else -> if (isExpired) HypeLabError.AdExpired() else HypeLabError.InternalError("Ad not ready. Call loadAd() first.")
            }
            onError?.invoke(error)
            return
        }

        val context = SdkCore.getContext()
        if (context == null) {
            onError?.invoke(HypeLabError.InternalError("Context unavailable"))
            return
        }

        state = State.SHOWING
        log("Showing ad...")

        // Data is already in FullscreenAdData format and cached by SdkCore.onInterstitialLoaded()
        // Just launch the unified full-screen Activity
        val intent = Intent(context, FullscreenActivity::class.java).apply {
            putExtra(FullscreenActivity.EXTRA_PLACEMENT_ID, placementId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * Cancel any in-progress ad load.
     * Use this to abandon an ad flow without destroying the ad unit.
     * The interstitial can be reused by calling loadAd() again.
     */
    fun cancel() {
        if (state != State.LOADING) {
            log("Cancel called but not loading (state=$state)")
            return
        }

        log("Cancelling load")
        stopExpirationTimer()
        SdkCore.cancelInterstitialLoad(placementId)
        adData = null
        loadedAtTime = null
        state = State.IDLE
    }

    /**
     * Destroy the interstitial and release resources.
     * Call this when you're done with the interstitial (e.g., Activity onDestroy).
     */
    fun destroy() {
        log("Destroying")
        stopExpirationTimer()

        // Notify JS to clean up handler
        SdkCore.destroyInterstitialInJs(placementId)
        SdkCore.unregisterInterstitial(placementId)

        adData = null

        // Clear callbacks to break retain cycles (per PRD Section 8.3)
        onReady = null
        onError = null
        onImpression = null
        onClick = null
        onClose = null
        onExpired = null

        state = State.IDLE
    }

    // =========================================================================
    // Internal callbacks (called by SdkCore)
    // =========================================================================

    internal fun _onAdLoaded(data: FullscreenAdData) {
        adData = data
        loadedAtTime = System.currentTimeMillis()

        mainHandler.post {
            state = State.LOADED
            log("Ad ready: ${data.creativeType}")
            onReady?.invoke()

            // Schedule expiration callback
            startExpirationTimer()
        }
    }

    private fun startExpirationTimer() {
        stopExpirationTimer()

        expirationRunnable = Runnable {
            if (state == State.LOADED) {
                log("Ad expired")
                mainHandler.post { onExpired?.invoke() }
            }
        }

        // Fire callback when ad expires
        mainHandler.postDelayed(expirationRunnable!!, AD_TTL_MS)
    }

    private fun stopExpirationTimer() {
        expirationRunnable?.let { mainHandler.removeCallbacks(it) }
        expirationRunnable = null
    }

    internal fun _onAdError(error: HypeLabError) {
        state = State.ERROR
        mainHandler.post {
            log("Ad error: ${error.message}")
            onError?.invoke(error)
        }
    }

    internal fun _onImpression() {
        mainHandler.post {
            log("Impression")
            onImpression?.invoke()
        }
    }

    internal fun _onClick() {
        mainHandler.post {
            log("Click")
            onClick?.invoke()
        }
    }

    internal fun _onClose() {
        mainHandler.post {
            log("Close")
            state = State.DISMISSED
            onClose?.invoke()
        }
    }

    private fun log(message: String) {
        if (HypeLab.isInitialized && HypeLab.config.debug) {
            Log.d(TAG, "[Interstitial:$placementSlug] $message")
        }
    }

    private enum class State {
        IDLE,       // Initial state
        LOADING,    // loadAd() called, waiting for response
        LOADED,     // Ad loaded and ready to show
        SHOWING,    // Ad is currently being displayed
        DISMISSED,  // Ad was closed by user
        ERROR       // Load failed
    }

    companion object {
        private const val TAG = "HypeLab"
        private const val AD_TTL_MS = 60 * 60 * 1000L  // 1 hour (PRD Section 8.2)
    }
}
