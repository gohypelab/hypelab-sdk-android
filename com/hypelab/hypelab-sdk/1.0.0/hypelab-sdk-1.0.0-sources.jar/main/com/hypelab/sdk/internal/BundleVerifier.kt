package com.hypelab.sdk.internal

import android.content.Context
import android.util.Log
import com.hypelab.sdk.R
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PublicKey
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.Base64

/**
 * ECDSA signature verification for OTA bundles.
 * Uses P-256 (prime256v1) curve with SHA256 digest.
 *
 * PRD Section 9: OTA Updates - Signature verification
 *
 * Usage:
 *   // Initialize with embedded public key
 *   BundleVerifier.initialize(context)
 *
 *   // Add additional keys from API (key rotation)
 *   BundleVerifier.addTrustedKey(pemKey)
 *
 *   // Verify a bundle
 *   val isValid = BundleVerifier.verify(bundleContent, signatureBase64)
 */
internal object BundleVerifier {
    private const val TAG = "HypeLab"
    private const val ALGORITHM = "SHA256withECDSA"
    private const val KEY_ALGORITHM = "EC"

    private var trustedKeys: List<TrustedKey> = emptyList()
    private var isInitialized = false

    /**
     * Represents a trusted public key with its identifier.
     */
    data class TrustedKey(
        val keyId: String,
        val publicKey: PublicKey
    )

    /**
     * Initialize with embedded public key from resources.
     * Call this once during SDK initialization.
     *
     * @param context Application context
     */
    fun initialize(context: Context) {
        if (isInitialized) {
            Log.d(TAG, "BundleVerifier.initialize: Already initialized, skipping")
            return
        }

        Log.d(TAG, "BundleVerifier.initialize: Starting...")
        try {
            // Load embedded public key from res/raw/bundle_signing_key.pem
            Log.d(TAG, "BundleVerifier.initialize: Loading embedded key from res/raw/bundle_signing_key.pem...")
            val pem = context.resources.openRawResource(R.raw.bundle_signing_key)
                .bufferedReader()
                .use { it.readText() }

            Log.d(TAG, "BundleVerifier.initialize: Loaded PEM (${pem.length} chars)")
            Log.d(TAG, "BundleVerifier.initialize: PEM content:\n$pem")

            Log.d(TAG, "BundleVerifier.initialize: Parsing public key...")
            val publicKey = parsePublicKey(pem)
            Log.d(TAG, "BundleVerifier.initialize: Public key parsed: ${publicKey.algorithm}")

            Log.d(TAG, "BundleVerifier.initialize: Computing key ID...")
            val keyId = computeKeyId(pem)
            Log.d(TAG, "BundleVerifier.initialize: Key ID = $keyId")

            trustedKeys = listOf(TrustedKey(keyId, publicKey))
            isInitialized = true

            Log.i(TAG, "BundleVerifier.initialize: SUCCESS - initialized with embedded key: $keyId")
        } catch (e: Exception) {
            Log.e(TAG, "BundleVerifier.initialize: FAILED - ${e.message}", e)
            // Continue without embedded key - API can provide keys
            isInitialized = true
            Log.w(TAG, "BundleVerifier.initialize: Continuing without embedded key, API must provide keys")
        }
    }

    /**
     * Add additional trusted keys from API response.
     * Used for key rotation support.
     *
     * @param keyId Key identifier (first 16 chars of SHA256 hash)
     * @param pemKey PEM-encoded public key
     */
    fun addTrustedKey(keyId: String, pemKey: String) {
        try {
            // Skip if already have this key
            if (trustedKeys.any { it.keyId == keyId }) return

            val publicKey = parsePublicKey(pemKey)
            trustedKeys = trustedKeys + TrustedKey(keyId, publicKey)

            Log.d(TAG, "Added trusted key: $keyId")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add trusted key $keyId: ${e.message}")
        }
    }

    /**
     * Verify bundle content against a Base64-encoded signature.
     * Tries all trusted keys until one verifies.
     *
     * @param content Bundle content bytes
     * @param signatureBase64 Base64-encoded ECDSA signature
     * @return true if signature is valid against any trusted key
     */
    fun verify(content: ByteArray, signatureBase64: String): Boolean {
        Log.d(TAG, "BundleVerifier.verify: Starting signature verification...")
        Log.d(TAG, "BundleVerifier.verify: Content size = ${content.size} bytes")
        Log.d(TAG, "BundleVerifier.verify: Signature (base64) length = ${signatureBase64.length}")

        if (trustedKeys.isEmpty()) {
            Log.e(TAG, "BundleVerifier.verify: NO TRUSTED KEYS AVAILABLE!")
            return false
        }

        Log.d(TAG, "BundleVerifier.verify: Trusted keys available: ${trustedKeys.size}")
        trustedKeys.forEachIndexed { index, key ->
            Log.d(TAG, "BundleVerifier.verify:   Key $index: ${key.keyId}")
        }

        return try {
            Log.d(TAG, "BundleVerifier.verify: Decoding base64 signature...")
            val signatureBytes = Base64.getDecoder().decode(signatureBase64)
            Log.d(TAG, "BundleVerifier.verify: Signature decoded, ${signatureBytes.size} bytes")

            var verified = false
            for (trustedKey in trustedKeys) {
                try {
                    Log.d(TAG, "BundleVerifier.verify: Trying key ${trustedKey.keyId}...")
                    val sig = Signature.getInstance(ALGORITHM)
                    sig.initVerify(trustedKey.publicKey)
                    sig.update(content)
                    val valid = sig.verify(signatureBytes)

                    if (valid) {
                        Log.i(TAG, "BundleVerifier.verify: SUCCESS with key ${trustedKey.keyId}")
                        verified = true
                        break
                    } else {
                        Log.d(TAG, "BundleVerifier.verify: Key ${trustedKey.keyId} did not verify")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "BundleVerifier.verify: Exception with key ${trustedKey.keyId}: ${e.message}")
                }
            }

            if (!verified) {
                Log.e(TAG, "BundleVerifier.verify: FAILED - no key verified the signature")
            }
            verified
        } catch (e: Exception) {
            Log.e(TAG, "BundleVerifier.verify: Exception: ${e.message}", e)
            false
        }
    }

    /**
     * Compute SHA256 hash of content.
     *
     * @param content Content bytes
     * @return Hex-encoded hash string
     */
    fun computeHash(content: ByteArray): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(content)
            .joinToString("") { "%02x".format(it) }
    }

    /**
     * Verify that content hash matches expected hash.
     *
     * @param content Content bytes
     * @param expectedHash Expected hex-encoded hash
     * @return true if hashes match
     */
    fun verifyHash(content: ByteArray, expectedHash: String): Boolean {
        val actualHash = computeHash(content)
        return actualHash.equals(expectedHash, ignoreCase = true)
    }

    /**
     * Check if verifier has any trusted keys.
     */
    fun hasTrustedKeys(): Boolean = trustedKeys.isNotEmpty()

    /**
     * Get the number of trusted keys.
     */
    fun trustedKeyCount(): Int = trustedKeys.size

    /**
     * Clear all trusted keys. Used for testing.
     */
    internal fun clearKeys() {
        trustedKeys = emptyList()
    }

    /**
     * Parse a PEM-encoded public key.
     */
    private fun parsePublicKey(pem: String): PublicKey {
        val cleaned = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .replace("\n", "")
            .replace("\r", "")
            .trim()

        val keyBytes = Base64.getDecoder().decode(cleaned)
        val keySpec = X509EncodedKeySpec(keyBytes)
        val keyFactory = KeyFactory.getInstance(KEY_ALGORITHM)

        return keyFactory.generatePublic(keySpec)
    }

    /**
     * Compute key ID from PEM key (first 16 chars of SHA256 hash).
     * Matches the Rails SdkSigningKey#compute_key_id implementation.
     */
    private fun computeKeyId(pem: String): String {
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(pem.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

        return hash.substring(0, 16)
    }
}
