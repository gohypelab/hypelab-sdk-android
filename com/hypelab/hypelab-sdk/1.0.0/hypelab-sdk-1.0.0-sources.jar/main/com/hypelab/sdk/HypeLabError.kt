package com.hypelab.sdk

/**
 * SDK error types.
 *
 * Error codes match the PRD specification (Section 8.4).
 */
sealed class HypeLabError(
    val code: Int,
    override val message: String,
    override val cause: Throwable? = null
) : Exception(message, cause) {

    /** 1001 - Network connectivity or HTTP error */
    class NetworkError(cause: Throwable? = null) : HypeLabError(1001, "Network error: ${cause?.message}", cause)

    /** 1002 - No ad available for this placement */
    class NoFill : HypeLabError(1002, "No ad available for this placement")

    /** 1003 - Invalid or unknown placement slug */
    class InvalidPlacement : HypeLabError(1003, "Invalid placement slug")

    /** 1004 - Ad has expired (loaded but not shown within TTL) */
    class AdExpired : HypeLabError(1004, "Ad has expired")

    /** 1005 - Attempted to show ad while another is already showing */
    class AdAlreadyShowing : HypeLabError(1005, "An ad is already showing")

    /** 1006 - SDK not initialized before use */
    class NotInitialized : HypeLabError(1006, "SDK not initialized. Call HypeLab.initialize() first.")

    /** 1007 - Server returned an error response */
    class ServerError(details: String? = null) : HypeLabError(1007, "Server error${details?.let { ": $it" } ?: ""}")

    /** 1008 - Request timed out */
    class Timeout : HypeLabError(1008, "Request timed out")

    /** 1009 - Server response was malformed or unparseable */
    class InvalidResponse(details: String? = null) : HypeLabError(1009, "Invalid response${details?.let { ": $it" } ?: ""}")

    /** 1010 - Ad load already in progress (non-PRD, but useful) */
    class LoadInProgress : HypeLabError(1010, "Ad load already in progress")

    /** 1011 - Too many ad requests (rate limited) */
    class AdLoadingThrottled : HypeLabError(1011, "Ad loading throttled - too many requests")

    /** 1099 - Unexpected internal error */
    class InternalError(details: String) : HypeLabError(1099, "Internal error: $details")

    override fun toString() = "HypeLabError($code): $message"
}
