package com.hypelab.sdk

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.hypelab.sdk.internal.SdkCore
import java.util.UUID

/**
 * Native ad unit.
 *
 * Native ads are publisher-templated: the SDK provides structured data,
 * and the publisher controls rendering in their own UI views.
 *
 * Usage:
 * ```kotlin
 * val native = Native("your-placement-slug")
 *
 * native.onReady = { ad ->
 *     // Bind assets to your UI
 *     headlineLabel.text = ad.headline
 *     bodyLabel.text = ad.body
 *     ctaButton.text = ad.ctaText
 *
 *     // Load images (publisher responsibility)
 *     Glide.with(context).load(ad.iconUrl).into(iconImageView)
 *     Glide.with(context).load(ad.imageUrl).into(mediaImageView)
 *
 *     // Register view for impression/click tracking
 *     ad.registerView(nativeAdContainer, listOf(ctaButton, headlineLabel))
 * }
 * native.onError = { error -> Log.e("Ad", "Error: $error") }
 * native.onImpression = { Log.d("Ad", "Impression") }
 * native.onClick = { Log.d("Ad", "Click") }
 *
 * native.loadAd()
 * ```
 */
class Native(val placementSlug: String) {
    internal val placementId: String = UUID.randomUUID().toString()

    private val mainHandler = Handler(Looper.getMainLooper())

    // State
    private var state: State = State.IDLE
    private var nativeAd: NativeAd? = null

    // Ad expiration (PRD: 1 hour TTL)
    private var loadedAtTime: Long? = null

    // Auto-refresh (matching web SDK behavior - 30 second interval)
    private var refreshRunnable: Runnable? = null
    private var autoRefreshEnabled = true

    // Public callbacks (matching PRD Section 3.2)
    var onReady: ((NativeAd) -> Unit)? = null
    var onError: ((HypeLabError) -> Unit)? = null
    var onImpression: (() -> Unit)? = null
    var onClick: (() -> Unit)? = null
    var onExpired: (() -> Unit)? = null

    /**
     * Callback fired when the ad is about to auto-refresh.
     * Publisher can use this to update their UI or prevent refresh.
     * Return false from this callback to prevent the refresh.
     */
    var onRefresh: (() -> Boolean)? = null

    /**
     * Returns true when an ad is loaded, ready to display, and not expired.
     */
    val isReady: Boolean get() = state == State.READY && !isExpired

    /**
     * Returns true if the native ad is currently showing (view is registered and visible).
     */
    val isShowing: Boolean get() = nativeAd?.isViewRegisteredAndAttached == true

    /**
     * Returns true if the loaded ad has expired (older than 1 hour).
     */
    val isExpired: Boolean get() {
        val loaded = loadedAtTime ?: return false
        return System.currentTimeMillis() - loaded > AD_TTL_MS
    }

    /**
     * The loaded native ad. Returns null until ad is loaded.
     */
    val ad: NativeAd? get() = if (isReady) nativeAd else null

    /**
     * Enable or disable auto-refresh for this native ad.
     * When enabled, the ad will automatically refresh every 30 seconds.
     * Default is enabled (matching web SDK behavior).
     *
     * @param enabled true to enable auto-refresh, false to disable
     */
    fun setAutoRefreshEnabled(enabled: Boolean) {
        autoRefreshEnabled = enabled
        if (!enabled) {
            stopAutoRefresh()
        }
        log("Auto-refresh: ${if (enabled) "enabled" else "disabled"}")
    }

    /** Whether auto-refresh is currently enabled */
    val isAutoRefreshEnabled: Boolean get() = autoRefreshEnabled

    init {
        if (!HypeLab.isInitialized) {
            Log.e(TAG, "SDK not initialized. Call HypeLab.initialize() first.")
        }
        SdkCore.registerNative(this)
    }

    /**
     * Load an ad. Call this before accessing ad assets.
     */
    fun loadAd() {
        if (!HypeLab.isInitialized) {
            onError?.invoke(HypeLabError.NotInitialized())
            return
        }

        if (state == State.LOADING) {
            onError?.invoke(HypeLabError.LoadInProgress())
            return
        }

        // Reset state for reload
        loadedAtTime = null
        nativeAd?.unregisterView()
        nativeAd = null

        state = State.LOADING
        log("Loading ad...")

        SdkCore.loadNativeAd(this) { result ->
            result.onFailure { error ->
                state = State.ERROR
                mainHandler.post {
                    onError?.invoke(error as? HypeLabError ?: HypeLabError.InternalError(error.message ?: "Unknown"))
                }
            }
            // onSuccess is handled via _onAdLoaded callback
        }
    }

    /**
     * Reload the native ad.
     */
    fun reload() {
        log("Reloading ad...")
        nativeAd?.unregisterView()
        nativeAd = null

        SdkCore.destroyNativeInJs(placementId)
        loadAd()
    }

    /**
     * Destroy the native ad and release resources.
     */
    fun destroy() {
        log("Destroying")
        stopAutoRefresh()
        nativeAd?.unregisterView()
        nativeAd = null

        SdkCore.destroyNativeInJs(placementId)
        SdkCore.unregisterNative(placementId)

        // Clear callbacks to break retain cycles (per PRD Section 8.3)
        onReady = null
        onError = null
        onImpression = null
        onClick = null
        onRefresh = null
        onExpired = null

        state = State.IDLE
    }

    // =========================================================================
    // Auto-refresh (matching web SDK 30 second interval)
    // =========================================================================

    private fun startAutoRefresh() {
        stopAutoRefresh()  // Clear any existing timer

        refreshRunnable = object : Runnable {
            override fun run() {
                if (!autoRefreshEnabled || state != State.READY) return

                // Check if ad has expired
                if (isExpired) {
                    log("Ad expired during auto-refresh timer")
                    stopAutoRefresh()
                    mainHandler.post { onExpired?.invoke() }
                    return
                }

                // Check if publisher wants to prevent refresh
                val shouldRefresh = onRefresh?.invoke() ?: true
                if (!shouldRefresh) {
                    log("Auto-refresh skipped by publisher")
                    mainHandler.postDelayed(this, REFRESH_INTERVAL_MS)
                    return
                }

                log("Auto-refreshing...")
                reload()
            }
        }

        mainHandler.postDelayed(refreshRunnable!!, REFRESH_INTERVAL_MS)
    }

    private fun stopAutoRefresh() {
        refreshRunnable?.let { mainHandler.removeCallbacks(it) }
        refreshRunnable = null
    }

    // =========================================================================
    // Internal callbacks (called by SdkCore)
    // =========================================================================

    internal fun _onAdLoaded(assetsJson: String) {
        try {
            val context = SdkCore.getContext() ?: throw IllegalStateException("Context unavailable")
            val assets = NativeAdAssets.fromJson(assetsJson)

            loadedAtTime = System.currentTimeMillis()

            mainHandler.post {
                nativeAd = NativeAd(placementId, assets, context).apply {
                    onImpressionInternal = { this@Native._onImpression() }
                    onClickInternal = { this@Native._onClick() }
                }

                state = State.READY
                log("Ad ready: ${assets.headline}")
                onReady?.invoke(nativeAd!!)

                // Start auto-refresh timer (matching web SDK 30 second interval)
                if (autoRefreshEnabled) {
                    startAutoRefresh()
                }
            }
        } catch (e: Exception) {
            _onAdError(HypeLabError.InvalidResponse("Failed to parse native assets: ${e.message}"))
        }
    }

    internal fun _onAdError(error: HypeLabError) {
        state = State.ERROR
        mainHandler.post {
            log("Ad error: ${error.message}")
            onError?.invoke(error)
        }
    }

    internal fun _onImpression() {
        mainHandler.post {
            log("Impression")
            onImpression?.invoke()
        }
    }

    internal fun _onClick() {
        mainHandler.post {
            log("Click")
            onClick?.invoke()
        }
    }

    private fun log(message: String) {
        if (HypeLab.isInitialized && HypeLab.config.debug) {
            Log.d(TAG, "[$placementSlug] $message")
        }
    }

    private enum class State {
        IDLE, LOADING, READY, ERROR
    }

    companion object {
        private const val TAG = "HypeLab"
        private const val AD_TTL_MS = 60 * 60 * 1000L  // 1 hour (PRD Section 8.2)
        private const val REFRESH_INTERVAL_MS = 30 * 1000L  // 30 seconds (matching web SDK)
    }
}
