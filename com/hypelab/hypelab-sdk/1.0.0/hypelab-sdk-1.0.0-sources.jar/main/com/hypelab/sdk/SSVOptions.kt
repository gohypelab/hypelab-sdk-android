package com.hypelab.sdk

/**
 * Server-Side Verification options for rewarded ads.
 *
 * SSV allows publishers to verify reward events server-to-server
 * for fraud prevention.
 *
 * ## SSV Flow
 *
 * 1. **Set SSVOptions before loading**: Set `ssvOptions` with your user ID before calling `loadAd()`.
 *    This allows the server to associate the ad request with a specific user.
 *
 * 2. **Server returns transaction_id**: When the ad loads, the server generates a unique
 *    `transaction_id` that will be included in both the reward callback and the SSV ping.
 *
 * 3. **Receive reward with transactionId**: When the user earns the reward, the `onReward`
 *    callback receives a [Reward] object containing the `transactionId`.
 *
 * 4. **Verify server-side**: HypeLab's server sends a signed callback to your SSV endpoint
 *    with the same `transaction_id`. Your server can verify the reward was legitimately
 *    granted by matching the `transaction_id` from both sources.
 *
 * ## Usage
 *
 * ```kotlin
 * val rewarded = Rewarded("your-placement-slug")
 *
 * // Step 1: Set SSV options BEFORE loading
 * rewarded.ssvOptions = SSVOptions(
 *     userID = "user123",
 *     customData = "level=5&item=boost"
 * )
 *
 * // Step 2: Load the ad (server generates transaction_id)
 * rewarded.loadAd()
 *
 * // Step 3: Handle reward with transaction_id
 * rewarded.onReward = { reward ->
 *     Log.d("SSV", "Reward earned: ${reward.amount} ${reward.type}")
 *     Log.d("SSV", "Transaction ID: ${reward.transactionId}")
 *
 *     // Optionally verify client-side or wait for server callback
 *     reward.transactionId?.let { txId ->
 *         // Send to your server to cross-reference with SSV callback
 *         verifyRewardWithServer(userId = "user123", transactionId = txId)
 *     }
 * }
 * ```
 *
 * @property userID Unique identifier for the user earning the reward
 * @property customData Optional URL-encoded custom data (e.g., game state, item ID)
 */
data class SSVOptions(
    val userID: String,
    val customData: String? = null
)
