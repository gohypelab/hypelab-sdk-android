package com.hypelab.sdk

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.hypelab.sdk.internal.SdkCore

/**
 * HypeLab SDK entry point.
 *
 * Initialize the SDK before creating any ad instances:
 * ```kotlin
 * HypeLab.initialize(context, "your-property-slug")
 * ```
 */
object HypeLab {
    const val VERSION = "1.0.0"

    private var _config: Config? = null
    val config: Config get() = _config ?: throw HypeLabError.NotInitialized()

    val isInitialized: Boolean get() = _config != null

    // Privacy & identity state
    private var _testMode: Boolean = false
    private var _walletAddresses: List<String> = emptyList()
    private var _gdprConsent: Boolean? = null
    private var _childDirectedTreatment: Boolean = false
    private var _underAgeOfConsent: Boolean = false
    private var _restrictedDataProcessing: Boolean = false

    // Secure storage for device ID
    private var securePrefs: SharedPreferences? = null
    private var cachedDeviceId: String? = null

    /**
     * Initialize the SDK. Must be called before creating any ad instances.
     *
     * @param context Application context
     * @param propertySlug Your HypeLab property slug
     * @param environment Target environment (default: PRODUCTION)
     * @param debug Enable debug logging (default: false)
     */
    fun initialize(
        context: Context,
        propertySlug: String,
        environment: Environment = Environment.PRODUCTION,
        debug: Boolean = false
    ) {
        val config = Config(
            propertySlug = propertySlug,
            environment = environment,
            debug = debug
        )
        initialize(context, config)
    }

    /**
     * Initialize the SDK with a config object.
     */
    fun initialize(context: Context, config: Config) {
        if (_config != null) {
            if (config.debug) {
                android.util.Log.w("HypeLab", "SDK already initialized, ignoring")
            }
            return
        }

        _config = config
        appContext = context.applicationContext

        android.util.Log.i("HypeLab", "=== SDK INITIALIZATION START ===")
        android.util.Log.i("HypeLab", "SDK Version: $VERSION")
        android.util.Log.i("HypeLab", "Environment: ${config.environment}")
        android.util.Log.i("HypeLab", "Property Slug: ${config.propertySlug}")
        android.util.Log.i("HypeLab", "Debug Mode: ${config.debug}")
        android.util.Log.i("HypeLab", "RTB Endpoint: ${config.rtbEndpoint}")
        android.util.Log.i("HypeLab", "Bundle URL: ${config.bundleUrl}")

        // Initialize secure storage for device ID
        android.util.Log.d("HypeLab", "Initializing secure storage...")
        initializeSecureStorage(context.applicationContext)
        android.util.Log.d("HypeLab", "Secure storage initialized, deviceID: $deviceID")

        android.util.Log.d("HypeLab", "Initializing SdkCore...")
        SdkCore.initialize(context.applicationContext, config)

        android.util.Log.i("HypeLab", "=== SDK INITIALIZATION COMPLETE ===")
    }

    private fun initializeSecureStorage(context: Context) {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            securePrefs = EncryptedSharedPreferences.create(
                context,
                "hypelab_secure_storage",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            android.util.Log.w("HypeLab", "Failed to create encrypted storage: ${e.message}")
            // Fallback to regular prefs
            securePrefs = context.getSharedPreferences("hypelab_storage", Context.MODE_PRIVATE)
        }
    }

    // =========================================================================
    // Device Identity (PRD Section 4.1.1)
    // =========================================================================

    /**
     * HypeLab Device ID - a persistent first-party identifier.
     * Stored in encrypted storage and survives app reinstalls (with backup enabled).
     */
    val deviceID: String
        get() {
            cachedDeviceId?.let { return it }

            val prefs = securePrefs ?: throw HypeLabError.NotInitialized()
            var id = prefs.getString("hypelab_device_id", null)
            if (id == null) {
                id = java.util.UUID.randomUUID().toString()
                prefs.edit().putString("hypelab_device_id", id).apply()
            }
            cachedDeviceId = id
            return id
        }

    // =========================================================================
    // Wallet Integration (PRD Section 4.4)
    // =========================================================================

    /**
     * Set wallet addresses for wallet-targeted advertising.
     * Call this when the user connects their wallet.
     *
     * @param addresses List of wallet addresses (Ethereum, Solana, etc.)
     */
    fun setWalletAddresses(addresses: List<String>) {
        _walletAddresses = addresses.toList()
        if (_config?.debug == true) {
            android.util.Log.d("HypeLab", "Wallet addresses set: ${addresses.size} address(es)")
        }
    }

    /**
     * Clear wallet addresses.
     * Call this when the user disconnects their wallet.
     */
    fun clearWalletAddresses() {
        _walletAddresses = emptyList()
        if (_config?.debug == true) {
            android.util.Log.d("HypeLab", "Wallet addresses cleared")
        }
    }

    /** Current wallet addresses (read-only) */
    val walletAddresses: List<String> get() = _walletAddresses.toList()

    // =========================================================================
    // Test Mode (PRD Section 8.5)
    // =========================================================================

    /**
     * Enable or disable test mode.
     * Test mode displays test ads safe to click during development.
     */
    fun setTestMode(enabled: Boolean) {
        _testMode = enabled
        if (_config?.debug == true) {
            android.util.Log.d("HypeLab", "Test mode: $enabled")
        }
    }

    /** Whether test mode is enabled */
    val isTestMode: Boolean get() = _testMode

    // =========================================================================
    // GDPR / TCF v2.2 Compliance (PRD Section 5.1)
    // =========================================================================

    // App context for reading SharedPreferences
    private var appContext: Context? = null

    /**
     * Check if GDPR consent has been granted.
     * Returns null if consent status is unknown.
     */
    val hasGDPRConsent: Boolean? get() = _gdprConsent

    /**
     * Manually set GDPR consent status.
     * Use this if not using a TCF-compliant CMP.
     *
     * @param granted true if user has given consent, false otherwise
     */
    fun setGDPRConsent(granted: Boolean) {
        _gdprConsent = granted
        if (_config?.debug == true) {
            android.util.Log.d("HypeLab", "GDPR consent: $granted")
        }
    }

    /**
     * Get the IAB TCF v2.2 consent string from standard SharedPreferences location.
     * CMPs like Google UMP, OneTrust, Didomi store the TC string here.
     *
     * @return The TC string if available, null otherwise
     */
    val tcfConsentString: String?
        get() {
            val ctx = appContext ?: return null
            val prefs = ctx.getSharedPreferences("${ctx.packageName}_preferences", Context.MODE_PRIVATE)
            return prefs.getString("IABTCF_TCString", null)
        }

    /**
     * Get the IAB Additional Consent string (for Google ATP vendors).
     *
     * @return The AC string if available, null otherwise
     */
    val tcfAdditionalConsent: String?
        get() {
            val ctx = appContext ?: return null
            val prefs = ctx.getSharedPreferences("${ctx.packageName}_preferences", Context.MODE_PRIVATE)
            return prefs.getString("IABTCF_AddtlConsent", null)
        }

    /**
     * Get the IAB GDPR applies flag from TCF.
     *
     * @return 1 if GDPR applies, 0 if not, null if unknown
     */
    val tcfGdprApplies: Int?
        get() {
            val ctx = appContext ?: return null
            val prefs = ctx.getSharedPreferences("${ctx.packageName}_preferences", Context.MODE_PRIVATE)
            return if (prefs.contains("IABTCF_gdprApplies")) {
                prefs.getInt("IABTCF_gdprApplies", 0)
            } else {
                null
            }
        }

    // =========================================================================
    // COPPA Compliance (PRD Section 5.2)
    // =========================================================================

    /**
     * Tag for child-directed treatment (COPPA).
     * When enabled, no behavioral targeting or device identifiers are collected.
     *
     * @param enabled true for apps directed at children under 13
     */
    fun setTagForChildDirectedTreatment(enabled: Boolean) {
        _childDirectedTreatment = enabled
        if (_config?.debug == true) {
            android.util.Log.d("HypeLab", "Child-directed treatment: $enabled")
        }
    }

    /** Whether child-directed treatment is enabled */
    val isChildDirectedTreatment: Boolean get() = _childDirectedTreatment

    // =========================================================================
    // CCPA / US State Privacy (PRD Section 5.3)
    // =========================================================================

    /**
     * Enable restricted data processing for CCPA compliance.
     * When enabled, SDK limits data collection and targeting.
     *
     * @param enabled true to enable restricted data processing
     */
    fun setRestrictedDataProcessing(enabled: Boolean) {
        _restrictedDataProcessing = enabled
        if (_config?.debug == true) {
            android.util.Log.d("HypeLab", "Restricted data processing: $enabled")
        }
    }

    /** Whether restricted data processing is enabled */
    val isRestrictedDataProcessing: Boolean get() = _restrictedDataProcessing

    // =========================================================================
    // TFUA Compliance (PRD Section 5.4)
    // =========================================================================

    /**
     * Tag for users under age of consent (typically 16 in EU).
     *
     * @param enabled true if user is under age of consent
     */
    fun setTagForUnderAgeOfConsent(enabled: Boolean) {
        _underAgeOfConsent = enabled
        if (_config?.debug == true) {
            android.util.Log.d("HypeLab", "Under age of consent: $enabled")
        }
    }

    /** Whether user is tagged as under age of consent */
    val isUnderAgeOfConsent: Boolean get() = _underAgeOfConsent

    // =========================================================================
    // Internal getters for SdkCore/JsBridge
    // =========================================================================

    internal fun getPrivacySettings(): PrivacySettings = PrivacySettings(
        gdprConsent = _gdprConsent,
        childDirectedTreatment = _childDirectedTreatment,
        underAgeOfConsent = _underAgeOfConsent,
        restrictedDataProcessing = _restrictedDataProcessing,
        tcfConsentString = tcfConsentString,
        tcfAdditionalConsent = tcfAdditionalConsent,
        tcfGdprApplies = tcfGdprApplies
    )

    internal data class PrivacySettings(
        val gdprConsent: Boolean?,
        val childDirectedTreatment: Boolean,
        val underAgeOfConsent: Boolean,
        val restrictedDataProcessing: Boolean,
        val tcfConsentString: String?,
        val tcfAdditionalConsent: String?,
        val tcfGdprApplies: Int?
    )

    // =========================================================================
    // Debug/Testing Utilities
    // =========================================================================

    /**
     * Clear the bundle cache and force re-download on next initialization.
     * For debugging/testing only - do not use in production.
     */
    fun clearBundleCache() {
        SdkCore.clearBundleCache()
    }

    /**
     * SDK configuration.
     */
    data class Config(
        val propertySlug: String,
        val environment: Environment = Environment.PRODUCTION,
        val debug: Boolean = false
    ) {
        val rtbEndpoint: String get() = when (environment) {
            Environment.PRODUCTION -> "https://api.hypelab.com/v1/rtb_requests"
            Environment.STAGING -> "https://api.hypelab-staging.com/v1/rtb_requests"
            Environment.DEVELOPMENT -> "https://api.lvh.me:8080/v1/rtb_requests"
        }

        val bundleUrl: String get() = when (environment) {
            Environment.PRODUCTION -> "https://api.hypelab.com/v1/sdk/bundle.js"
            Environment.STAGING -> "https://api.hypelab-staging.com/v1/sdk/bundle.js"
            Environment.DEVELOPMENT -> "https://api.lvh.me:8080/v1/sdk/bundle.js"
        }
    }

    /**
     * Target environment.
     */
    enum class Environment {
        PRODUCTION,
        STAGING,
        DEVELOPMENT
    }
}
