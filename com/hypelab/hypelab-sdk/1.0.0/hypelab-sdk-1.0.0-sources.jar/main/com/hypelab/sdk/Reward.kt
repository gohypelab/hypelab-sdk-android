package com.hypelab.sdk

/**
 * Represents a reward to be granted after completing a rewarded ad.
 *
 * @property type The type of reward (e.g., "coins", "gems", "extra_life")
 * @property amount The quantity of reward units
 * @property transactionId Unique transaction identifier for SSV (Server-Side Verification).
 *                         Use this to verify the reward was legitimately granted via your
 *                         SSV callback endpoint. Only present when SSVOptions was set before loadAd().
 */
data class Reward(
    val type: String,
    val amount: Int,
    val transactionId: String? = null
) {
    override fun toString() = "Reward(type=$type, amount=$amount, transactionId=$transactionId)"
}
