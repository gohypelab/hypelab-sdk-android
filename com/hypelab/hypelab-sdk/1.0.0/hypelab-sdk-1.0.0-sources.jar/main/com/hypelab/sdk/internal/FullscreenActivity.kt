package com.hypelab.sdk.internal

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.hypelab.sdk.FullscreenAdData
import com.hypelab.sdk.HypeLab
import com.hypelab.sdk.R

/**
 * Unified full-screen Activity for both interstitial and rewarded ads.
 *
 * Handles all 4 combinations:
 * - Video Interstitial: Close button after delay, no reward
 * - Video Rewarded: Non-skippable, reward + SSV, end card
 * - Display Interstitial: Close button (immediate or delayed), no reward
 * - Display Rewarded: Non-skippable (timer), reward + SSV, optional end card
 *
 * The ad mode (interstitial vs rewarded) determines behavior:
 * - Close button timing
 * - Reward granting
 * - Back button handling
 * - End card display
 */
internal class FullscreenActivity : AppCompatActivity() {

    // Display views
    private lateinit var webView: WebView

    // Native display views (used when nativeRender=true)
    private lateinit var nativeDisplayContainer: FrameLayout
    private lateinit var nativeDisplayImage: ImageView
    private lateinit var nativeDisplayClickOverlay: View

    // Video views
    private lateinit var playerView: PlayerView
    private lateinit var videoClickOverlay: View
    private lateinit var interstitialProgressBar: ProgressBar

    // Common views
    private lateinit var closeButton: ImageButton
    private lateinit var countdownText: TextView

    // CTA Bar views
    private lateinit var ctaBarContainer: LinearLayout
    private lateinit var ctaBarIcon: ImageView
    private lateinit var ctaBarText: TextView
    private lateinit var ctaBarButton: Button

    // End Card views
    private lateinit var endCardContainer: LinearLayout
    private lateinit var endCardIcon: ImageView
    private lateinit var endCardHeadline: TextView
    private lateinit var endCardBody: TextView
    private lateinit var endCardCta: Button

    // State
    private var placementId: String? = null
    private var adData: FullscreenAdData? = null
    private var closeButtonVisible = false
    private var impressionFired = false

    // Video state
    private var exoPlayer: ExoPlayer? = null
    private var videoDurationMs: Long = 0
    private var lastTrackedQuartile = 0
    private var videoStarted = false
    private var videoCompleted = false
    private var hasVideoError = false

    // Rewarded state
    private var rewardGranted = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var countdownRunnable: Runnable? = null
    private var progressUpdateRunnable: Runnable? = null

    companion object {
        const val EXTRA_PLACEMENT_ID = "placement_id"
        private const val TAG = "HypeLab"
        private const val PROGRESS_UPDATE_INTERVAL_MS = 250L
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full screen, no action bar
        supportActionBar?.hide()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_fullscreen)

        // Get placement ID and ad mode from intent
        placementId = intent.getStringExtra(EXTRA_PLACEMENT_ID)
        if (placementId == null) {
            log("No placement ID provided")
            notifyError("No placement ID provided")
            finish()
            return
        }

        // Retrieve cached ad data from SdkCore
        adData = SdkCore.getFullscreenAdData(placementId!!)
        if (adData == null) {
            log("No ad data found for placement: $placementId")
            notifyError("Ad data not found or expired")
            finish()
            return
        }

        initViews()
        setupBackPressHandler()
        loadAdContent()
    }

    private fun initViews() {
        // Display views
        webView = findViewById(R.id.adWebView)

        // Native display views
        nativeDisplayContainer = findViewById(R.id.nativeDisplayContainer)
        nativeDisplayImage = findViewById(R.id.nativeDisplayImage)
        nativeDisplayClickOverlay = findViewById(R.id.nativeDisplayClickOverlay)

        // Video views
        playerView = findViewById(R.id.playerView)
        videoClickOverlay = findViewById(R.id.videoClickOverlay)
        interstitialProgressBar = findViewById(R.id.interstitialProgressBar)

        // Common views
        closeButton = findViewById(R.id.closeButton)
        countdownText = findViewById(R.id.countdownText)

        // CTA Bar views
        ctaBarContainer = findViewById(R.id.ctaBarContainer)
        ctaBarIcon = findViewById(R.id.ctaBarIcon)
        ctaBarText = findViewById(R.id.ctaBarText)
        ctaBarButton = findViewById(R.id.ctaBarButton)

        // End Card views
        endCardContainer = findViewById(R.id.endCardContainer)
        endCardIcon = findViewById(R.id.endCardIcon)
        endCardHeadline = findViewById(R.id.endCardHeadline)
        endCardBody = findViewById(R.id.endCardBody)
        endCardCta = findViewById(R.id.endCardCta)

        // Setup click handlers
        closeButton.setOnClickListener { handleCloseAttempt() }
        videoClickOverlay.setOnClickListener { handleVideoClick() }
        ctaBarContainer.setOnClickListener { handleCtaBarClick() }
        ctaBarButton.setOnClickListener { handleCtaBarClick() }
        endCardCta.setOnClickListener { handleEndCardClick() }
        nativeDisplayClickOverlay.setOnClickListener { handleNativeDisplayClick() }
    }

    private fun setupBackPressHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (closeButtonVisible) {
                    handleCloseAttempt()
                } else {
                    log("Back button blocked - close not yet available")
                }
            }
        })
    }

    // =========================================================================
    // Content Loading
    // =========================================================================

    private fun loadAdContent() {
        val data = adData ?: return

        when (data.creativeType) {
            FullscreenAdData.CreativeType.DISPLAY -> loadDisplayCreative(data)
            FullscreenAdData.CreativeType.VIDEO -> loadVideoCreative(data)
        }
    }

    // =========================================================================
    // Display Creative Handling
    // =========================================================================

    @SuppressLint("SetJavaScriptEnabled")
    private fun loadDisplayCreative(data: FullscreenAdData) {
        // Hide video views
        playerView.visibility = View.GONE
        videoClickOverlay.visibility = View.GONE
        interstitialProgressBar.visibility = View.GONE

        setupDisplayBehavior(data)

        // Check if we should use native rendering (ImageView) or WebView
        if (data.nativeRender && data.imageUrl != null) {
            loadNativeDisplayCreative(data)
        } else {
            loadWebViewDisplayCreative(data)
        }
    }

    private fun loadNativeDisplayCreative(data: FullscreenAdData) {
        // Show native display container, hide WebView
        nativeDisplayContainer.visibility = View.VISIBLE
        webView.visibility = View.GONE

        // Load the main image (fitCenter to contain without clipping)
        Glide.with(this)
            .load(data.imageUrl)
            .fitCenter()
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>,
                    isFirstResource: Boolean
                ): Boolean {
                    log("Failed to load native display image: ${e?.message}")
                    // Fall back to WebView if image fails
                    if (data.adm != null) {
                        nativeDisplayContainer.visibility = View.GONE
                        loadWebViewDisplayCreative(data)
                    } else {
                        notifyError("Failed to load display image")
                        finish()
                    }
                    return true
                }

                override fun onResourceReady(
                    resource: Drawable,
                    model: Any,
                    target: Target<Drawable>?,
                    dataSource: DataSource,
                    isFirstResource: Boolean
                ): Boolean = false
            })
            .into(nativeDisplayImage)

        log("Loading native display creative (${data.adMode})")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun loadWebViewDisplayCreative(data: FullscreenAdData) {
        // Show WebView, hide native display container
        webView.visibility = View.VISIBLE
        nativeDisplayContainer.visibility = View.GONE

        setupWebView()

        // Load HTML content
        val html = wrapAdmInHtml(data.adm ?: "")
        val baseUrl = if (HypeLab.isInitialized) {
            HypeLab.config.rtbEndpoint.substringBeforeLast("/v1/") + "/"
        } else {
            "https://api.hypelab.com/"
        }
        webView.loadDataWithBaseURL(baseUrl, html, "text/html", "UTF-8", null)
        log("Loading WebView display creative (${data.adMode})")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return true
                handleClick(url)
                return true
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url != null) handleClick(url)
                return true
            }
        }
    }

    private fun setupDisplayBehavior(data: FullscreenAdData) {
        if (data.isRewarded()) {
            // Rewarded display: timer-based close
            val closeDelayMs = data.closeDelayMs.takeIf { it > 0 } ?: 15000L
            startCountdown(closeDelayMs)
        } else {
            // Interstitial display: immediate or delayed close
            val closeDelayMs = data.closeDelayMs
            if (closeDelayMs <= 0) {
                showCloseButton()
            } else {
                startCountdown(closeDelayMs)
            }
        }
    }

    // =========================================================================
    // Video Creative Handling
    // =========================================================================

    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    private fun loadVideoCreative(data: FullscreenAdData) {
        // Show video views, hide display views
        webView.visibility = View.GONE
        nativeDisplayContainer.visibility = View.GONE
        playerView.visibility = View.VISIBLE
        videoClickOverlay.visibility = View.VISIBLE

        val videoUrl = data.videoUrl
        if (videoUrl.isNullOrEmpty()) {
            log("No video URL available")
            notifyError("No video URL")
            finish()
            return
        }

        // Setup video UI (same for both interstitial and rewarded)
        setupVideoUI(data)

        // Setup CTA bar if server-configured
        setupCtaBar(data)

        // Initialize ExoPlayer
        exoPlayer = ExoPlayer.Builder(this).build().also { player ->
            playerView.player = player

            player.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_READY -> {
                            videoDurationMs = player.duration
                            interstitialProgressBar.max = videoDurationMs.toInt()
                            startProgressUpdates()
                        }
                        Player.STATE_ENDED -> onVideoCompleted()
                    }
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    if (isPlaying && !videoStarted) {
                        videoStarted = true
                        fireVideoEvent("start")
                        if (!impressionFired) fireImpression()
                        if (data.isRewarded()) {
                            notifyVideoStart()
                        }
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    log("Player error: ${error.message}")
                    hasVideoError = true
                    fireVideoEvent("error")
                    notifyVideoError(error.message ?: "Video playback error")
                    showCloseButton()
                }
            })

            val mediaItem = MediaItem.fromUri(Uri.parse(videoUrl))
            player.setMediaItem(mediaItem)
            player.prepare()
            player.playWhenReady = true
        }

        log("Loading video creative: $videoUrl (${data.adMode})")
    }

    private fun setupVideoUI(data: FullscreenAdData) {
        // Both interstitial and rewarded use bottom progress bar
        interstitialProgressBar.visibility = View.VISIBLE

        if (!data.isRewarded()) {
            // Interstitial: 5s timer before close button
            val closeDelayMs = data.skipDelayMs.takeIf { it > 0 } ?: 5000L
            startCountdown(closeDelayMs)
        }
        // Rewarded: close button shown after video completes (handled in onVideoCompleted)
    }

    private fun startProgressUpdates() {
        progressUpdateRunnable = object : Runnable {
            override fun run() {
                val player = exoPlayer ?: return
                val position = player.currentPosition
                val duration = player.duration

                if (duration > 0) {
                    interstitialProgressBar.progress = position.toInt()
                    trackQuartileEvents(position, duration)
                }

                mainHandler.postDelayed(this, PROGRESS_UPDATE_INTERVAL_MS)
            }
        }
        mainHandler.post(progressUpdateRunnable!!)
    }

    private fun stopProgressUpdates() {
        progressUpdateRunnable?.let { mainHandler.removeCallbacks(it) }
        progressUpdateRunnable = null
    }

    private fun trackQuartileEvents(position: Long, duration: Long) {
        if (duration <= 0) return

        val percentComplete = (position.toFloat() / duration * 100).toInt()

        if (percentComplete >= 25 && lastTrackedQuartile < 1) {
            lastTrackedQuartile = 1
            fireVideoEvent("firstQuartile")
        }
        if (percentComplete >= 50 && lastTrackedQuartile < 2) {
            lastTrackedQuartile = 2
            fireVideoEvent("midpoint")
        }
        if (percentComplete >= 75 && lastTrackedQuartile < 3) {
            lastTrackedQuartile = 3
            fireVideoEvent("thirdQuartile")
        }
    }

    private fun onVideoCompleted() {
        videoCompleted = true
        stopProgressUpdates()

        fireVideoEvent("complete")

        val data = adData ?: return

        if (data.isRewarded()) {
            notifyVideoComplete()
            grantReward()
            showEndCard(data)
        }

        showCloseButton()
        ctaBarContainer.visibility = View.GONE

        log("Video completed (${data.adMode})")
    }

    private fun fireVideoEvent(eventName: String) {
        val urls = adData?.videoEventUrls ?: return
        val id = placementId ?: return

        val url = getVideoEventUrl(urls, eventName) ?: return
        SdkCore.fireFullscreenVideoEvent(id, eventName, url)
        log("Video event: $eventName")
    }

    private fun getVideoEventUrl(urls: FullscreenAdData.VideoEventUrls, eventName: String): String? {
        return when (eventName) {
            "start" -> urls.start
            "firstQuartile" -> urls.firstQuartile
            "midpoint" -> urls.midpoint
            "thirdQuartile" -> urls.thirdQuartile
            "complete" -> urls.complete
            "error" -> urls.error
            else -> null
        }
    }

    // =========================================================================
    // End Card (Rewarded only)
    // =========================================================================

    private fun showEndCard(data: FullscreenAdData) {
        // Hide video player, overlay, display, and CTA bar; show end card
        playerView.visibility = View.GONE
        videoClickOverlay.visibility = View.GONE
        nativeDisplayContainer.visibility = View.GONE
        ctaBarContainer.visibility = View.GONE
        endCardContainer.visibility = View.VISIBLE

        // Populate end card with native assets
        endCardHeadline.text = data.headline
        endCardBody.text = data.body
        endCardCta.text = data.ctaText

        // Load icon if available
        loadImageWithFallback(data.iconUrl, endCardIcon, "icon")

        log("End card displayed")
    }

    // =========================================================================
    // CTA Bar (Server-Controlled)
    // =========================================================================

    private fun setupCtaBar(data: FullscreenAdData) {
        val ctaBar = data.ctaBar ?: return
        if (!ctaBar.enabled) return

        log("Setting up CTA bar: ${ctaBar.text}")

        ctaBarText.text = ctaBar.text
        ctaBarButton.text = data.ctaText

        ctaBar.backgroundColor?.let { colorStr ->
            try {
                val color = android.graphics.Color.parseColor(colorStr)
                ctaBarContainer.setBackgroundColor(color)
            } catch (e: Exception) {
                log("Invalid CTA bar background color: $colorStr")
            }
        }

        data.iconUrl?.let { iconUrl ->
            Glide.with(this).load(iconUrl).centerCrop().into(ctaBarIcon)
            ctaBarIcon.visibility = View.VISIBLE
        }

        ctaBarContainer.visibility = View.VISIBLE
    }

    // =========================================================================
    // Click Handlers
    // =========================================================================

    private fun handleClick(url: String) {
        log("Click: $url")
        fireClick()
        openUrl(url)
    }

    private fun handleVideoClick() {
        val clickUrl = getClickUrl() ?: return
        log("Video clicked during playback: $clickUrl")
        fireClick()
        openUrl(clickUrl)
    }

    private fun handleCtaBarClick() {
        val ctaBar = adData?.ctaBar ?: return
        val clickUrl = ctaBar.url.ifEmpty { getClickUrl() } ?: return
        log("CTA bar clicked: $clickUrl")
        fireClick()
        openUrl(clickUrl)
    }

    private fun getClickUrl(): String? = adData?.ctaLink ?: adData?.clickUrl

    private fun handleEndCardClick() {
        val clickUrl = getClickUrl() ?: return
        log("End card CTA clicked: $clickUrl")
        fireClick()
        openUrl(clickUrl)
    }

    private fun handleNativeDisplayClick() {
        val clickUrl = getClickUrl() ?: return
        log("Native display clicked: $clickUrl")
        fireClick()
        openUrl(clickUrl)
    }

    private fun openUrl(url: String) {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") {
            log("Blocked non-HTTP URL scheme: $scheme")
            return
        }

        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            log("Failed to open URL: ${e.message}")
        }
    }

    // =========================================================================
    // Close Handling
    // =========================================================================

    private fun startCountdown(delayMs: Long) {
        countdownText.visibility = View.VISIBLE
        closeButton.visibility = View.GONE

        var remainingSeconds = (delayMs / 1000).toInt()
        countdownText.text = remainingSeconds.toString()

        countdownRunnable = object : Runnable {
            override fun run() {
                remainingSeconds--
                if (remainingSeconds > 0) {
                    countdownText.text = remainingSeconds.toString()
                    mainHandler.postDelayed(this, 1000)
                } else {
                    // For rewarded display ads, grant reward when countdown completes
                    val data = adData
                    if (data != null && data.isRewarded() && !data.isVideo()) {
                        grantReward()
                    }
                    showCloseButton()
                }
            }
        }
        mainHandler.postDelayed(countdownRunnable!!, 1000)
    }

    private fun showCloseButton() {
        countdownText.visibility = View.GONE
        closeButton.visibility = View.VISIBLE
        closeButtonVisible = true
        log("Close button visible")
    }

    private fun handleCloseAttempt() {
        val data = adData ?: return

        // Don't show forfeit dialog if:
        // - Not a rewarded ad
        // - Reward was already granted
        // - Video already completed
        // - There was a video error (user couldn't earn reward anyway)
        if (data.isRewarded() && !rewardGranted && !videoCompleted && !hasVideoError) {
            showForfeitRewardDialog()
        } else {
            handleClose()
        }
    }

    private fun showForfeitRewardDialog() {
        AlertDialog.Builder(this)
            .setTitle("Close Ad?")
            .setMessage("You'll forfeit your reward if you close now. Are you sure?")
            .setPositiveButton("Keep Watching") { dialog, _ ->
                dialog.dismiss()
            }
            .setNegativeButton("Close Anyway") { _, _ ->
                handleClose()
            }
            .setCancelable(false)
            .show()
    }

    private fun handleClose() {
        log("User closed fullscreen ad (rewardGranted=$rewardGranted)")
        notifyClose()
        finish()
    }

    // =========================================================================
    // Tracking & Notifications
    // =========================================================================

    private fun fireImpression() {
        if (impressionFired) return
        impressionFired = true

        placementId?.let { id ->
            SdkCore.fireFullscreenImpression(id)
            log("Impression fired")
        }
    }

    private fun fireClick() {
        placementId?.let { id ->
            SdkCore.fireFullscreenClick(id)
        }
    }

    private fun grantReward() {
        if (rewardGranted) return
        rewardGranted = true

        placementId?.let { id ->
            SdkCore.onFullscreenRewardGranted(id)
            log("Reward granted")
        }
    }

    private fun notifyVideoStart() {
        placementId?.let { SdkCore.onFullscreenVideoStart(it) }
    }

    private fun notifyVideoComplete() {
        placementId?.let { SdkCore.onFullscreenVideoComplete(it) }
    }

    private fun notifyVideoError(message: String) {
        placementId?.let { SdkCore.onFullscreenVideoError(it, message) }
    }

    private fun notifyClose() {
        placementId?.let { SdkCore.onFullscreenClose(it) }
    }

    private fun notifyError(message: String) {
        placementId?.let { SdkCore.onFullscreenError(it, message) }
            ?: SdkCore.onFullscreenError("", message)
    }

    // =========================================================================
    // Lifecycle
    // =========================================================================

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)

        // Fire impression when window gains focus (ensures activity is actually visible)
        if (hasFocus && !impressionFired && adData?.creativeType == FullscreenAdData.CreativeType.DISPLAY) {
            fireImpression()
        }

        // Pause/resume video when window focus changes
        if (adData?.isVideo() == true) {
            if (hasFocus) {
                exoPlayer?.play()
            } else {
                exoPlayer?.pause()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        countdownRunnable?.let { mainHandler.removeCallbacks(it) }
        countdownRunnable = null

        stopProgressUpdates()

        exoPlayer?.release()
        exoPlayer = null

        if (::webView.isInitialized) {
            webView.destroy()
        }

        log("Activity destroyed")
    }

    // =========================================================================
    // Utilities
    // =========================================================================

    private fun loadImageWithFallback(url: String?, imageView: ImageView, description: String) {
        if (url == null) {
            imageView.visibility = View.GONE
            return
        }

        Glide.with(this)
            .load(url)
            .centerCrop()
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>,
                    isFirstResource: Boolean
                ): Boolean {
                    log("Failed to load $description: ${e?.message}")
                    imageView.visibility = View.GONE
                    return true
                }

                override fun onResourceReady(
                    resource: Drawable,
                    model: Any,
                    target: Target<Drawable>?,
                    dataSource: DataSource,
                    isFirstResource: Boolean
                ): Boolean = false
            })
            .into(imageView)
        imageView.visibility = View.VISIBLE
    }

    private fun wrapAdmInHtml(adm: String): String {
        if (adm.trimStart().startsWith("<!DOCTYPE", ignoreCase = true) ||
            adm.trimStart().startsWith("<html", ignoreCase = true)) {
            return adm
        }

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                <style>
                    * {
                        box-sizing: border-box;
                    }
                    html, body {
                        margin: 0;
                        padding: 0;
                        width: 100%;
                        height: 100%;
                        background: #000;
                        overflow: hidden;
                    }
                    body {
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    /* Container scales content to fill screen while maintaining aspect ratio */
                    .fullscreen-container {
                        width: 100vw;
                        height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    .fullscreen-container > * {
                        max-width: 100%;
                        max-height: 100%;
                        width: 100%;
                        height: auto;
                        object-fit: contain;
                    }
                    /* Images scale to fill width, centered vertically */
                    .fullscreen-container img {
                        width: 100%;
                        height: auto;
                        max-height: 100vh;
                        object-fit: contain;
                    }
                    /* iframes/embeds fill the container */
                    .fullscreen-container iframe,
                    .fullscreen-container video {
                        width: 100%;
                        height: 100%;
                        border: none;
                    }
                </style>
            </head>
            <body>
                <div class="fullscreen-container">
                    $adm
                </div>
            </body>
            </html>
        """.trimIndent()
    }

    private fun log(message: String) {
        if (HypeLab.isInitialized && HypeLab.config.debug) {
            Log.d(TAG, "[FullscreenActivity] $message")
        }
    }
}
