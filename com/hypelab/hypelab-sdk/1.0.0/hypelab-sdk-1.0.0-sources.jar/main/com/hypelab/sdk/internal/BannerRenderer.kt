package com.hypelab.sdk.internal

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.util.Log
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * Renders banner ad HTML in a WebView.
 */
internal class BannerRenderer(
    private val context: Context,
    private val mainHandler: Handler,
    private val adWidth: Int,   // CSS pixels from bid
    private val adHeight: Int   // CSS pixels from bid
) {
    companion object {
        private const val TAG = "HypeLab"
        private const val MRC_VIEWABILITY_THRESHOLD = 0.5f
        private const val BASE_URL = "https://api.hypelab-staging.com/"
    }

    val webView: WebView
    var onClick: ((String) -> Unit)? = null

    init {
        webView = createWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val screenWidthPx = context.resources.displayMetrics.widthPixels
        val aspectRatio = adHeight.toFloat() / adWidth.toFloat()
        val scaledHeightPx = (screenWidthPx * aspectRatio).toInt()

        return WebView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                scaledHeightPx
            )
            setBackgroundColor(Color.TRANSPARENT)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                loadsImagesAutomatically = true
                blockNetworkImage = false
                useWideViewPort = false
                loadWithOverviewMode = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                cacheMode = WebSettings.LOAD_DEFAULT
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val url = request?.url?.toString() ?: return false
                    Log.d(TAG, "Banner click: $url")
                    onClick?.invoke(url)
                    openInBrowser(url)
                    return true
                }
            }
        }
    }

    fun loadHtml(html: String) {
        val screenWidthPx = context.resources.displayMetrics.widthPixels
        val scaleFactor = (screenWidthPx.toFloat() / adWidth * 100).toInt()

        mainHandler.post {
            webView.setInitialScale(scaleFactor)
            webView.loadDataWithBaseURL(BASE_URL, html, "text/html", "UTF-8", null)
        }
    }

    fun getViewability(): ViewabilityResult {
        val visibleRect = Rect()
        if (!webView.getGlobalVisibleRect(visibleRect) || webView.width == 0 || webView.height == 0) {
            return ViewabilityResult(0f, false)
        }

        val visibleArea = visibleRect.width() * visibleRect.height()
        val totalArea = webView.width * webView.height
        val visiblePercent = visibleArea.toFloat() / totalArea

        return ViewabilityResult(visiblePercent, visiblePercent >= MRC_VIEWABILITY_THRESHOLD)
    }

    fun destroy() {
        mainHandler.post {
            (webView.parent as? FrameLayout)?.removeView(webView)
            webView.stopLoading()
            webView.destroy()
        }
    }

    private fun openInBrowser(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open URL: $url", e)
        }
    }

    data class ViewabilityResult(
        val visiblePercent: Float,
        val isViewable: Boolean
    )
}
