package com.hypelab.sdk.internal

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.util.Log
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Renders banner ad HTML in a WebView.
 */
internal class BannerRenderer(
    private val context: Context,
    private val mainHandler: Handler,
    private val adWidth: Int,   // CSS pixels from bid
    private val adHeight: Int   // CSS pixels from bid
) {
    companion object {
        private const val TAG = "HypeLab"
        private const val MRC_VIEWABILITY_THRESHOLD = 0.5f
        private const val BASE_URL = "https://api.hypelab-staging.com/"
    }

    val webView: WebView
    val containerView: FrameLayout
    var onClick: ((String) -> Unit)? = null

    init {
        webView = createWebView()
        containerView = createSafeAreaContainer()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        return WebView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.TRANSPARENT)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                loadsImagesAutomatically = true
                blockNetworkImage = false
                useWideViewPort = false
                loadWithOverviewMode = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                cacheMode = WebSettings.LOAD_DEFAULT
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val url = request?.url?.toString() ?: return false
                    Log.d(TAG, "Banner click: $url")
                    onClick?.invoke(url)
                    openInBrowser(url)
                    return true
                }
            }
        }
    }

    fun loadHtml(html: String) {
        val screenWidthPx = context.resources.displayMetrics.widthPixels
        val scaleFactor = (screenWidthPx.toFloat() / adWidth * 100).toInt()

        mainHandler.post {
            webView.setInitialScale(scaleFactor)
            webView.loadDataWithBaseURL(BASE_URL, html, "text/html", "UTF-8", null)
        }
    }

    fun getViewability(): ViewabilityResult {
        val visibleRect = Rect()
        if (!webView.getGlobalVisibleRect(visibleRect) || webView.width == 0 || webView.height == 0) {
            return ViewabilityResult(0f, false)
        }

        val visibleArea = visibleRect.width() * visibleRect.height()
        val totalArea = webView.width * webView.height
        val visiblePercent = visibleArea.toFloat() / totalArea

        return ViewabilityResult(visiblePercent, visiblePercent >= MRC_VIEWABILITY_THRESHOLD)
    }

    fun destroy() {
        mainHandler.post {
            (containerView.parent as? ViewGroup)?.removeView(containerView)
            webView.stopLoading()
            webView.destroy()
        }
    }

    private fun createSafeAreaContainer(): FrameLayout {
        val screenWidthPx = context.resources.displayMetrics.widthPixels
        val aspectRatio = adHeight.toFloat() / adWidth.toFloat()
        val scaledHeightPx = (screenWidthPx * aspectRatio).toInt()

        return FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                scaledHeightPx
            )
            addView(webView)

            addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
                applySafeAreaPadding(v)
            }

            addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) {
                    v.post { applySafeAreaPadding(v) }
                }
                override fun onViewDetachedFromWindow(v: View) {}
            })
        }
    }

    /**
     * Detects if the banner overlaps unsafe display areas (status bar, navigation bar,
     * display cutout/notch) and applies padding to keep content within the safe area.
     *
     * Uses [ViewCompat.getRootWindowInsets] which returns raw window insets regardless of
     * whether a parent view (or Compose) has consumed them.
     */
    private fun applySafeAreaPadding(view: View) {
        val rootInsets = ViewCompat.getRootWindowInsets(view) ?: return
        val insets = rootInsets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        )

        val rootWidth = view.rootView.width
        val rootHeight = view.rootView.height
        if (rootWidth == 0 || rootHeight == 0) return

        val location = IntArray(2)
        view.getLocationInWindow(location)
        val viewTop = location[1]
        val viewBottom = viewTop + view.height
        val viewLeft = location[0]
        val viewRight = viewLeft + view.width

        val topOverlap = maxOf(0, insets.top - viewTop)
        val bottomOverlap = maxOf(0, viewBottom - (rootHeight - insets.bottom))
        val leftOverlap = maxOf(0, insets.left - viewLeft)
        val rightOverlap = maxOf(0, viewRight - (rootWidth - insets.right))

        if (view.paddingTop != topOverlap || view.paddingBottom != bottomOverlap ||
            view.paddingLeft != leftOverlap || view.paddingRight != rightOverlap) {
            view.setPadding(leftOverlap, topOverlap, rightOverlap, bottomOverlap)

            if (topOverlap > 0 || bottomOverlap > 0 || leftOverlap > 0 || rightOverlap > 0) {
                Log.w(TAG, "Banner overlaps unsafe display area. " +
                    "Auto-adjusted padding: top=${topOverlap}px, bottom=${bottomOverlap}px, " +
                    "left=${leftOverlap}px, right=${rightOverlap}px. " +
                    "Consider placing the banner within your app's safe area.")
            }
        }
    }

    private fun openInBrowser(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open URL: $url", e)
        }
    }

    data class ViewabilityResult(
        val visiblePercent: Float,
        val isViewable: Boolean
    )
}
