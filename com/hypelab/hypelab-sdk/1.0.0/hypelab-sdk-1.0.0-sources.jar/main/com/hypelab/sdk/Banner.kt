package com.hypelab.sdk

import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import com.hypelab.sdk.internal.BannerRenderer
import com.hypelab.sdk.internal.SdkCore
import java.util.UUID

/**
 * Banner ad unit.
 *
 * Usage:
 * ```kotlin
 * val banner = Banner("your-placement-slug", BannerSize.STANDARD)
 *
 * banner.onReady = { Log.d("Ad", "Banner ready") }
 * banner.onError = { error -> Log.e("Ad", "Error: $error") }
 * banner.onImpression = { Log.d("Ad", "Impression") }
 * banner.onClick = { Log.d("Ad", "Click") }
 *
 * banner.loadAd()
 *
 * // When ready, add to your layout
 * container.addView(banner.view)
 * ```
 */
class Banner(
    val placementSlug: String,
    val size: BannerSize = BannerSize.STANDARD
) {
    internal val placementId: String = UUID.randomUUID().toString()

    private val mainHandler = Handler(Looper.getMainLooper())

    // State
    private var state: State = State.IDLE
    private var renderer: BannerRenderer? = null
    private var adm: String? = null
    private var adWidth: Int = size.width
    private var adHeight: Int = size.height

    // Ad expiration (PRD: 1 hour TTL)
    private var loadedAtTime: Long? = null
    private var refreshInterval: Long? = null  // Server-controlled refresh interval in ms

    // Viewability tracking
    private var impressionFired = false
    private var viewableStartTime: Long? = null
    private var viewabilityRunnable: Runnable? = null
    private var autoRefreshRunnable: Runnable? = null

    // Public callbacks (matching PRD)
    var onReady: (() -> Unit)? = null
    var onError: ((HypeLabError) -> Unit)? = null
    var onImpression: (() -> Unit)? = null
    var onClick: (() -> Unit)? = null
    var onClose: (() -> Unit)? = null
    var onExpired: (() -> Unit)? = null

    /**
     * Returns true when an ad is loaded, ready to display, and not expired.
     */
    val isReady: Boolean get() = (state == State.READY || state == State.SHOWING) && !isExpired

    /**
     * Returns true if the banner is currently showing (view is attached to window).
     */
    val isShowing: Boolean get() = state == State.SHOWING || (renderer?.containerView?.isAttachedToWindow == true)

    /**
     * Returns true if the loaded ad has expired (older than 1 hour).
     */
    val isExpired: Boolean get() {
        val loaded = loadedAtTime ?: return false
        return System.currentTimeMillis() - loaded > AD_TTL_MS
    }

    /**
     * The view to add to your layout. Returns null until ad is loaded.
     */
    val view: View? get() = renderer?.containerView

    init {
        if (!HypeLab.isInitialized) {
            Log.e(TAG, "SDK not initialized. Call HypeLab.initialize() first.")
        }
        SdkCore.registerBanner(this)
    }

    /**
     * Load an ad. Call this before showing the banner.
     */
    fun loadAd() {
        if (!HypeLab.isInitialized) {
            onError?.invoke(HypeLabError.NotInitialized())
            return
        }

        if (state == State.LOADING) {
            onError?.invoke(HypeLabError.LoadInProgress())
            return
        }

        // Reset state for reload
        impressionFired = false
        viewableStartTime = null
        loadedAtTime = null
        stopAutoRefresh()

        state = State.LOADING
        log("Loading ad...")

        SdkCore.loadBannerAd(this) { result ->
            result.onFailure { error ->
                state = State.ERROR
                mainHandler.post {
                    onError?.invoke(error as? HypeLabError ?: HypeLabError.InternalError(error.message ?: "Unknown"))
                }
            }
            // onSuccess is handled via _onAdLoaded callback
        }
    }

    /**
     * Reload the banner ad. Useful for manual refresh or after expiration.
     */
    fun reload() {
        log("Reloading ad...")
        stopViewabilityTracking()
        stopAutoRefresh()

        // Destroy old renderer
        renderer?.destroy()
        renderer = null

        // Notify JS to clean up old handler
        SdkCore.destroyBannerInJs(placementId)

        // Load fresh ad
        loadAd()
    }

    /**
     * Destroy the banner and release resources.
     */
    fun destroy() {
        log("Destroying")
        stopViewabilityTracking()
        stopAutoRefresh()

        renderer?.destroy()
        renderer = null

        // Notify JS to clean up handler
        SdkCore.destroyBannerInJs(placementId)
        SdkCore.unregisterBanner(placementId)

        // Notify onClose callback
        mainHandler.post { onClose?.invoke() }

        // Clear callbacks to break retain cycles (per PRD Section 8.3)
        onReady = null
        onError = null
        onImpression = null
        onClick = null
        onClose = null
        onExpired = null

        state = State.IDLE
    }

    // =========================================================================
    // Internal callbacks (called by SdkCore)
    // =========================================================================

    internal fun _onAdLoaded(width: Int, height: Int, adm: String, refreshIntervalMs: Long? = null) {
        this.adWidth = width
        this.adHeight = height
        this.adm = adm
        this.loadedAtTime = System.currentTimeMillis()
        this.refreshInterval = refreshIntervalMs

        mainHandler.post {
            // Create renderer with bid dimensions
            val context = SdkCore.getContext() ?: return@post
            val handler = SdkCore.getMainHandler()

            renderer = BannerRenderer(context, handler, width, height).apply {
                onClick = { url ->
                    this@Banner._onClick()
                }
            }

            // Load the HTML
            renderer?.loadHtml(adm)

            state = State.READY
            log("Ad ready: ${width}x${height}")
            onReady?.invoke()

            // Start viewability tracking when view is attached
            startViewabilityTracking()

            // Start auto-refresh if server specified an interval
            if (refreshIntervalMs != null && refreshIntervalMs > 0) {
                startAutoRefresh(refreshIntervalMs)
            }
        }
    }

    internal fun _onAdError(error: HypeLabError) {
        state = State.ERROR
        mainHandler.post {
            log("Ad error: ${error.message}")
            onError?.invoke(error)
        }
    }

    internal fun _onImpression() {
        if (!impressionFired) {
            impressionFired = true
            mainHandler.post {
                log("Impression")
                onImpression?.invoke()
            }
        }
    }

    internal fun _onClick() {
        // Fire click tracking via JS bundle (PRD Section 9.4)
        SdkCore.fireClick(placementId)

        mainHandler.post {
            log("Click")
            onClick?.invoke()
        }
    }

    // =========================================================================
    // Viewability tracking (MRC: 50% visible for 1 second)
    // =========================================================================

    private fun startViewabilityTracking() {
        if (impressionFired) return

        viewabilityRunnable = object : Runnable {
            override fun run() {
                if (impressionFired || renderer == null) return

                // Check if ad has expired
                if (isExpired) {
                    log("Ad expired during viewability tracking")
                    stopViewabilityTracking()
                    mainHandler.post { onExpired?.invoke() }
                    return
                }

                val result = renderer?.getViewability() ?: return

                if (result.isViewable) {
                    if (viewableStartTime == null) {
                        viewableStartTime = System.currentTimeMillis()
                    } else if (System.currentTimeMillis() - viewableStartTime!! >= MRC_VIEW_TIME_MS) {
                        // MRC threshold met - fire impression via JS bundle
                        impressionFired = true
                        SdkCore.fireImpression(placementId)
                        stopViewabilityTracking()
                        return
                    }
                } else {
                    viewableStartTime = null
                }

                mainHandler.postDelayed(this, VIEWABILITY_CHECK_INTERVAL_MS)
            }
        }

        mainHandler.postDelayed(viewabilityRunnable!!, VIEWABILITY_CHECK_INTERVAL_MS)
    }

    private fun stopViewabilityTracking() {
        viewabilityRunnable?.let { mainHandler.removeCallbacks(it) }
        viewabilityRunnable = null
    }

    // =========================================================================
    // Auto-refresh (server-controlled, only when visible)
    // =========================================================================

    private fun startAutoRefresh(intervalMs: Long) {
        stopAutoRefresh()

        autoRefreshRunnable = object : Runnable {
            override fun run() {
                // Only refresh if still visible
                val result = renderer?.getViewability()
                if (result?.isViewable == true) {
                    log("Auto-refreshing (interval: ${intervalMs}ms)")
                    reload()
                } else {
                    // Not visible, check again later
                    mainHandler.postDelayed(this, VIEWABILITY_CHECK_INTERVAL_MS)
                }
            }
        }

        mainHandler.postDelayed(autoRefreshRunnable!!, intervalMs)
    }

    private fun stopAutoRefresh() {
        autoRefreshRunnable?.let { mainHandler.removeCallbacks(it) }
        autoRefreshRunnable = null
    }

    private fun log(message: String) {
        if (HypeLab.isInitialized && HypeLab.config.debug) {
            Log.d(TAG, "[$placementSlug] $message")
        }
    }

    private enum class State {
        IDLE, LOADING, READY, SHOWING, ERROR
    }

    companion object {
        private const val TAG = "HypeLab"
        private const val AD_TTL_MS = 60 * 60 * 1000L  // 1 hour (PRD Section 8.2)
        private const val MRC_VIEW_TIME_MS = 1000L     // 1 second for MRC viewability
        private const val VIEWABILITY_CHECK_INTERVAL_MS = 100L
    }
}
