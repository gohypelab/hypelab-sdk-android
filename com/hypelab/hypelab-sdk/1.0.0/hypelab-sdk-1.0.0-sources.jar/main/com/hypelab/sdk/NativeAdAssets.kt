package com.hypelab.sdk

import android.util.Log
import org.json.JSONObject

/**
 * Native ad asset container.
 *
 * Assets match OpenRTB Native 1.2 response format as used by HypeLab web SDK.
 * See: sdk-v2/packages/sdk-core/src/components/rtb_native.ts
 *
 * Asset ID mapping:
 * - 1: title -> headline
 * - 2: data type 1 (sponsored) -> advertiser
 * - 3: data type 2 (desc) -> body
 * - 4: data type 11 -> displayUrl
 * - 5: data type 12 -> ctaText
 * - 6: img type 1 -> iconUrl
 * - 7: img type 3 -> imageUrl (main image)
 * - 8: video -> videoUrl (extracted from VAST tag)
 * - 9: data type 3 (rating) -> starRating (PRD Section 3.2)
 *
 * Required assets: headline, advertiser, body, displayUrl, ctaText, iconUrl
 * Optional assets: imageUrl, videoUrl (one of these will be present for media), starRating
 */
data class NativeAdAssets(
    // Required assets (matching web SDK)
    val headline: String,
    val advertiser: String,
    val body: String,
    val displayUrl: String,
    val ctaText: String,
    val iconUrl: String,

    // Optional media assets - one of these will be present
    val imageUrl: String? = null,
    val videoUrl: String? = null, // Extracted from VAST tag by JS bundle

    // Optional rating asset (PRD Section 3.2)
    val starRating: Double? = null,

    // Internal - click destination from response.link.url
    internal val ctaLink: String
) {
    companion object {
        private const val TAG = "HypeLab"

        /**
         * Parse from JSON string received from JS bridge.
         * Expected format matches OpenRTB Native 1.2 asset structure.
         */
        internal fun fromJson(json: String): NativeAdAssets {
            Log.d(TAG, "NativeAdAssets.fromJson received: $json")

            val obj = JSONObject(json)

            // Debug: Check what's in the JSON for media assets
            val rawImageUrl = obj.optString("imageUrl", null)
            val rawVideoUrl = obj.optString("videoUrl", null)
            Log.d(TAG, "Raw imageUrl from JSON: $rawImageUrl")
            Log.d(TAG, "Raw videoUrl from JSON: $rawVideoUrl")

            // Parse optional star rating
            val rawStarRating = if (obj.has("starRating") && !obj.isNull("starRating")) {
                obj.optDouble("starRating", Double.NaN)
            } else {
                Double.NaN
            }
            Log.d(TAG, "Raw starRating from JSON: $rawStarRating")

            val assets = NativeAdAssets(
                headline = obj.getString("headline"),
                advertiser = obj.getString("advertiser"),
                body = obj.getString("body"),
                displayUrl = obj.getString("displayUrl"),
                ctaText = obj.getString("ctaText"),
                iconUrl = obj.getString("iconUrl"),
                imageUrl = rawImageUrl?.takeIf { it.isNotEmpty() && it != "null" },
                videoUrl = rawVideoUrl?.takeIf { it.isNotEmpty() && it != "null" },
                starRating = if (rawStarRating.isNaN()) null else rawStarRating,
                ctaLink = obj.getString("ctaLink")
            )

            Log.d(TAG, "Parsed imageUrl: ${assets.imageUrl}")
            Log.d(TAG, "Parsed videoUrl: ${assets.videoUrl}")
            Log.d(TAG, "Parsed starRating: ${assets.starRating}")

            return assets
        }
    }
}
