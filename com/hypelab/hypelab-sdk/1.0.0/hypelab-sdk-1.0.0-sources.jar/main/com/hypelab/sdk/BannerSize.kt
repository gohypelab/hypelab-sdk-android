package com.hypelab.sdk

/**
 * Standard banner sizes.
 *
 * @property width Banner width in CSS pixels
 * @property height Banner height in CSS pixels
 */
enum class BannerSize(val width: Int, val height: Int) {
    /** 320x50 - Standard phone banner */
    STANDARD(320, 50),

    /** 320x100 - Large phone banner */
    LARGE(320, 100),

    /** 300x250 - Medium rectangle (MREC) */
    MREC(300, 250),

    /** 728x90 - Tablet leaderboard */
    LEADERBOARD(728, 90);

    override fun toString() = "${width}x${height}"
}
