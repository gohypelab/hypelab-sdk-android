package com.hypelab.sdk

import org.json.JSONObject

/**
 * Unified data class for fullscreen ads (interstitial + rewarded).
 *
 * Supports all 4 combinations:
 * - Video Interstitial: Skippable, no reward
 * - Video Rewarded: Non-skippable, reward + SSV
 * - Display Interstitial: Skippable, no reward
 * - Display Rewarded: Non-skippable (timer-based), reward + SSV
 *
 * Note: Tracking URLs (burl, nurl, imptrackers, clicktrackers) are handled by the JS bundle.
 * This data class only stores what's needed for UI rendering on the native side.
 */
internal data class FullscreenAdData(
    val adMode: AdMode,                   // INTERSTITIAL or REWARDED
    val creativeType: CreativeType,       // VIDEO or DISPLAY

    // Creative content
    val adm: String?,                     // HTML markup for display (null if nativeRender=true)
    val videoUrl: String?,                // Extracted video URL from VAST
    val videoEventUrls: VideoEventUrls?,  // VAST event tracking URLs

    // Native rendering (display only)
    val nativeRender: Boolean,            // True = use ImageView, False = use WebView
    val imageUrl: String?,                // Image URL for native rendering

    // Behavior
    val skipDelayMs: Long,                // 0 for rewarded (non-skippable)
    val closeDelayMs: Long,               // When close button appears for display

    // Native assets (for video end card)
    val headline: String,
    val body: String,
    val ctaText: String,
    val ctaLink: String,
    val iconUrl: String?,

    // Reward (null for interstitial)
    val reward: Reward?,

    // Optional CTA bar (server-configurable)
    val ctaBar: CtaBar?,

    // Click URL for tracking (fired via JS bundle)
    val clickUrl: String?
) {
    enum class AdMode {
        INTERSTITIAL,  // Skippable, no reward
        REWARDED       // Non-skippable, with reward
    }

    enum class CreativeType {
        VIDEO,    // VAST video creative
        DISPLAY   // HTML/image creative
    }

    /**
     * VAST video event tracking URLs.
     */
    data class VideoEventUrls(
        val start: String?,
        val firstQuartile: String?,
        val midpoint: String?,
        val thirdQuartile: String?,
        val complete: String?,
        val error: String?
    )

    /**
     * Optional bottom bar CTA configuration (server-configurable).
     */
    data class CtaBar(
        val enabled: Boolean,
        val text: String,
        val url: String,
        val backgroundColor: String?
    )

    companion object {
        /**
         * Parse from JSON string received from JS bridge.
         */
        fun fromJson(json: String): FullscreenAdData {
            val obj = JSONObject(json)

            val adMode = when (obj.optString("adMode", "interstitial").lowercase()) {
                "rewarded" -> AdMode.REWARDED
                else -> AdMode.INTERSTITIAL
            }

            val creativeType = when (obj.optString("creativeType", "display").lowercase()) {
                "video" -> CreativeType.VIDEO
                else -> CreativeType.DISPLAY
            }

            // Parse reward (only for rewarded mode)
            val rewardObj = obj.optJSONObject("reward")
            val reward = if (adMode == AdMode.REWARDED && rewardObj != null) {
                Reward(
                    type = rewardObj.optString("type", "reward"),
                    amount = rewardObj.optInt("amount", 1),
                    transactionId = rewardObj.optString("transaction_id", null)?.takeIf { it.isNotEmpty() }
                )
            } else null

            // Parse video event URLs if present
            val videoEventsObj = obj.optJSONObject("videoEventUrls")
            val videoEventUrls = videoEventsObj?.let {
                VideoEventUrls(
                    start = it.optString("start", null).takeIf { s -> s.isNotEmpty() },
                    firstQuartile = it.optString("firstQuartile", null).takeIf { s -> s.isNotEmpty() },
                    midpoint = it.optString("midpoint", null).takeIf { s -> s.isNotEmpty() },
                    thirdQuartile = it.optString("thirdQuartile", null).takeIf { s -> s.isNotEmpty() },
                    complete = it.optString("complete", null).takeIf { s -> s.isNotEmpty() },
                    error = it.optString("error", null).takeIf { s -> s.isNotEmpty() }
                )
            }

            // Parse CTA bar config if present
            val ctaBarObj = obj.optJSONObject("ctaBar")
            val ctaBar = ctaBarObj?.let {
                CtaBar(
                    enabled = it.optBoolean("enabled", false),
                    text = it.optString("text", ""),
                    url = it.optString("url", ""),
                    backgroundColor = it.optString("background_color", null).takeIf { s -> s.isNotEmpty() }
                )
            }

            // Parse native rendering flag (display only)
            val nativeRender = obj.optBoolean("nativeRender", false)

            return FullscreenAdData(
                adMode = adMode,
                creativeType = creativeType,

                // Creative content
                adm = obj.optString("adm", null).takeIf { it.isNotEmpty() },
                videoUrl = obj.optString("videoUrl", null).takeIf { it.isNotEmpty() },
                videoEventUrls = videoEventUrls,

                // Native rendering (display only)
                nativeRender = nativeRender,
                imageUrl = obj.optString("imageUrl", null).takeIf { it.isNotEmpty() },

                // Behavior
                skipDelayMs = obj.optLong("skipDelayMs", if (adMode == AdMode.REWARDED) 0 else 5000),
                closeDelayMs = obj.optLong("closeDelayMs", when {
                    adMode == AdMode.REWARDED && creativeType == CreativeType.DISPLAY -> 15000
                    adMode == AdMode.INTERSTITIAL && creativeType == CreativeType.DISPLAY -> 5000
                    else -> 0
                }),

                // Native assets (for video end card)
                headline = obj.optString("headline", ""),
                body = obj.optString("body", ""),
                ctaText = obj.optString("ctaText", "Learn More"),
                ctaLink = obj.optString("ctaLink", ""),
                iconUrl = obj.optString("iconUrl", null).takeIf { it.isNotEmpty() },

                // Reward
                reward = reward,

                // CTA bar
                ctaBar = ctaBar,

                // Click URL (tracking fired via JS bundle)
                clickUrl = obj.optString("clickUrl", null).takeIf { it.isNotEmpty() }
            )
        }
    }

    /**
     * Check if this is a rewarded ad.
     */
    fun isRewarded(): Boolean = adMode == AdMode.REWARDED

    /**
     * Check if this is a video creative.
     */
    fun isVideo(): Boolean = creativeType == CreativeType.VIDEO
}
