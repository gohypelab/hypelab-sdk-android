package com.hypelab.sdk

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import com.hypelab.sdk.internal.SdkCore

/**
 * Represents a loaded native ad with assets and tracking capabilities.
 *
 * This object is passed to the publisher via the onReady callback.
 * Publisher binds assets to their UI, then calls registerView() to enable tracking.
 *
 * Example:
 * ```kotlin
 * native.onReady = { ad ->
 *     headlineLabel.text = ad.headline
 *     bodyLabel.text = ad.body
 *     ctaButton.text = ad.ctaText
 *     Glide.with(context).load(ad.iconUrl).into(iconImageView)
 *
 *     // Register view for impression/click tracking
 *     ad.registerView(nativeAdContainer, listOf(ctaButton, headlineLabel))
 * }
 * ```
 */
class NativeAd internal constructor(
    private val placementId: String,
    private val assets: NativeAdAssets,
    private val context: Context
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    // Viewability tracking state
    private var registeredView: View? = null
    private var clickableViews: List<View> = emptyList()
    private var impressionFired = false
    private var viewableStartTime: Long? = null
    private var viewabilityRunnable: Runnable? = null

    // =========================================================================
    // Public asset accessors (PRD Section 3.2)
    // =========================================================================

    /** Primary ad title */
    val headline: String get() = assets.headline

    /** Advertiser/sponsor name */
    val advertiser: String get() = assets.advertiser

    /** Ad description text */
    val body: String get() = assets.body

    /** Display URL for transparency */
    val displayUrl: String get() = assets.displayUrl

    /** Call-to-action button text */
    val ctaText: String get() = assets.ctaText

    /** Advertiser logo/icon image URL */
    val iconUrl: String get() = assets.iconUrl

    /** Main image URL (optional - either imageUrl or videoUrl will be present) */
    val imageUrl: String? get() = assets.imageUrl

    /** Video URL extracted from VAST (optional - either imageUrl or videoUrl will be present) */
    val videoUrl: String? get() = assets.videoUrl

    /** App store rating (optional, PRD Section 3.2) */
    val starRating: Double? get() = assets.starRating

    // Internal callbacks (set by Native class)
    internal var onImpressionInternal: (() -> Unit)? = null
    internal var onClickInternal: (() -> Unit)? = null

    /** Internal: Check if ad view is currently showing */
    internal val isViewRegisteredAndAttached: Boolean
        get() = registeredView?.isAttachedToWindow == true

    /**
     * Register the view hierarchy for impression and click tracking.
     *
     * @param containerView The root view containing the native ad layout.
     *                      Used for viewability measurement.
     * @param clickableViews Views that should trigger click events when tapped.
     *                       Typically includes CTA button, headline, etc.
     *
     * Example:
     * ```kotlin
     * ad.registerView(nativeAdContainer, listOf(ctaButton, headlineLabel))
     * ```
     */
    fun registerView(containerView: View, clickableViews: List<View> = emptyList()) {
        this.registeredView = containerView
        this.clickableViews = clickableViews

        // Set up click listeners on specified views
        val clickListener = View.OnClickListener {
            handleClick()
        }

        clickableViews.forEach { view ->
            view.setOnClickListener(clickListener)
        }

        // If no specific clickable views, make entire container clickable
        if (clickableViews.isEmpty()) {
            containerView.setOnClickListener(clickListener)
        }

        // Start viewability tracking
        startViewabilityTracking()

        log("View registered for tracking")
    }

    /**
     * Unregister view and stop tracking.
     * Called internally when Native.destroy() is invoked.
     */
    internal fun unregisterView() {
        stopViewabilityTracking()

        clickableViews.forEach { view ->
            view.setOnClickListener(null)
        }
        registeredView?.setOnClickListener(null)

        registeredView = null
        clickableViews = emptyList()
    }

    // =========================================================================
    // Viewability Tracking (MRC: 50% visible for 1 second)
    // =========================================================================

    private fun startViewabilityTracking() {
        if (impressionFired) return

        viewabilityRunnable = object : Runnable {
            override fun run() {
                if (impressionFired || registeredView == null) return

                val isViewable = checkViewability()

                if (isViewable) {
                    if (viewableStartTime == null) {
                        viewableStartTime = System.currentTimeMillis()
                    } else if (System.currentTimeMillis() - viewableStartTime!! >= MRC_VIEW_TIME_MS) {
                        // MRC threshold met - fire impression
                        impressionFired = true
                        SdkCore.fireImpression(placementId)
                        onImpressionInternal?.invoke()
                        stopViewabilityTracking()
                        log("Impression fired (MRC threshold met)")
                        return
                    }
                } else {
                    viewableStartTime = null
                }

                mainHandler.postDelayed(this, VIEWABILITY_CHECK_INTERVAL_MS)
            }
        }

        mainHandler.postDelayed(viewabilityRunnable!!, VIEWABILITY_CHECK_INTERVAL_MS)
    }

    private fun stopViewabilityTracking() {
        viewabilityRunnable?.let { mainHandler.removeCallbacks(it) }
        viewabilityRunnable = null
    }

    /**
     * Check if registered view meets MRC viewability threshold.
     * Returns true if 50%+ of the view is visible in the viewport.
     */
    private fun checkViewability(): Boolean {
        val view = registeredView ?: return false

        // Check if view is attached and visible
        if (!view.isShown || view.width == 0 || view.height == 0) {
            return false
        }

        val visibleRect = Rect()
        if (!view.getGlobalVisibleRect(visibleRect)) {
            return false
        }

        val visibleArea = visibleRect.width() * visibleRect.height()
        val totalArea = view.width * view.height
        val visiblePercent = visibleArea.toFloat() / totalArea

        return visiblePercent >= MRC_VIEWABILITY_THRESHOLD
    }

    // =========================================================================
    // Click Handling
    // =========================================================================

    private fun handleClick() {
        // Fire click tracking via JS bundle (uses bid.ext.curl)
        SdkCore.fireClick(placementId)

        // Notify publisher callback
        onClickInternal?.invoke()

        // Open destination URL in browser
        openUrl(assets.ctaLink)

        log("Click handled")
    }

    private fun openUrl(url: String) {
        try {
            val uri = Uri.parse(url)

            // Validate URL scheme to prevent malicious intents (e.g., file://, javascript:)
            val scheme = uri.scheme?.lowercase()
            if (scheme != "http" && scheme != "https") {
                Log.w(TAG, "Blocked non-HTTP URL scheme: $scheme")
                return
            }

            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open URL: $url", e)
        }
    }

    private fun log(message: String) {
        if (HypeLab.isInitialized && HypeLab.config.debug) {
            Log.d(TAG, "[NativeAd:$placementId] $message")
        }
    }

    companion object {
        private const val TAG = "HypeLab"
        private const val MRC_VIEWABILITY_THRESHOLD = 0.5f
        private const val MRC_VIEW_TIME_MS = 1000L
        private const val VIEWABILITY_CHECK_INTERVAL_MS = 100L
    }
}
