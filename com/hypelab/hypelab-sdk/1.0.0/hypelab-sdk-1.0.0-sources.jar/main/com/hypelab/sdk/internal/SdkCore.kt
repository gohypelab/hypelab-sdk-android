package com.hypelab.sdk.internal

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import com.hypelab.sdk.Banner
import com.hypelab.sdk.FullscreenAdData
import com.hypelab.sdk.HypeLab
import com.hypelab.sdk.HypeLabError
import com.hypelab.sdk.Interstitial
import com.hypelab.sdk.Native
import com.hypelab.sdk.Rewarded
import java.io.IOException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Internal SDK core - manages OTA WebView and ad coordination.
 *
 * Note: This singleton stores ApplicationContext (not Activity context),
 * which is safe and won't cause memory leaks.
 */
@SuppressLint("StaticFieldLeak")
internal object SdkCore {
    private const val TAG = "HypeLab"

    /**
     * Escape a string for safe use in JavaScript string literals.
     * Prevents injection attacks from malicious placement slugs or other user input.
     */
    private fun escapeJsString(value: String): String = value
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
        .replace("\u2028", "\\u2028")  // Line separator
        .replace("\u2029", "\\u2029")  // Paragraph separator

    /**
     * Execute JavaScript code in the bundle WebView.
     * Wraps in IIFE and posts to main handler.
     */
    private fun evaluateJs(js: String) {
        mainHandler.post {
            bundleWebView?.evaluateJavascript(js, null)
        }
    }

    /**
     * Build and execute a JS function call with null-safety check.
     */
    private fun callJsFunction(functionPath: String, vararg args: String) {
        if (!isReady) return

        val argsStr = args.joinToString(", ")
        val js = """
            (function() {
                if (typeof HypeLab !== 'undefined' && HypeLab.$functionPath) {
                    HypeLab.$functionPath($argsStr);
                }
            })();
        """.trimIndent()

        evaluateJs(js)
    }

    private var context: Context? = null
    private var config: HypeLab.Config? = null
    private var bundleWebView: WebView? = null
    private var bridge: JsBridge? = null
    private var bundleManager: BundleManager? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Active banner instances keyed by placement ID
    private val banners = mutableMapOf<String, Banner>()

    // Active native instances keyed by placement ID
    private val natives = mutableMapOf<String, Native>()

    // Active interstitial instances keyed by placement ID
    private val interstitials = mutableMapOf<String, Interstitial>()

    // Active rewarded instances keyed by placement ID
    private val rewardeds = mutableMapOf<String, Rewarded>()

    // Cached ad data for FullscreenActivity to retrieve
    private val fullscreenAdData = mutableMapOf<String, FullscreenAdData>()

    // Pending callbacks for banner operations
    private val pendingLoads = mutableMapOf<String, (Result<Unit>) -> Unit>()

    // Pending callbacks for native operations
    private val pendingNativeLoads = mutableMapOf<String, (Result<Unit>) -> Unit>()

    // Pending callbacks for interstitial operations
    private val pendingInterstitialLoads = mutableMapOf<String, (Result<Unit>) -> Unit>()

    // Pending callbacks for rewarded operations
    private val pendingRewardedLoads = mutableMapOf<String, (Result<Unit>) -> Unit>()

    var isReady = false
        private set

    private var onReadyCallbacks = mutableListOf<() -> Unit>()

    @SuppressLint("SetJavaScriptEnabled")
    fun initialize(appContext: Context, sdkConfig: HypeLab.Config) {
        if (context != null) {
            Log.w(TAG, "SdkCore already initialized, skipping")
            return
        }

        Log.i(TAG, "=== SdkCore.initialize() START ===")
        context = appContext
        config = sdkConfig

        Log.d(TAG, "Creating BundleManager...")
        bundleManager = BundleManager(appContext, sdkConfig)
        Log.d(TAG, "BundleManager created")

        Log.d(TAG, "Posting to main handler to create WebView and load bundle...")
        mainHandler.post {
            Log.d(TAG, "Main handler: Creating bundle WebView...")
            createBundleWebView(appContext)
            Log.d(TAG, "Main handler: WebView created, loading bundle...")
            loadBundle()
        }
        Log.i(TAG, "=== SdkCore.initialize() END (async bundle load started) ===")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createBundleWebView(context: Context) {
        bundleWebView = WebView(context).apply {
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(1, 1)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
            }

            bridge = JsBridge(context, this)
            addJavascriptInterface(bridge!!, "HypeLabBridge")

            if (config?.debug == true) {
                webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                        Log.d(TAG, "[JS] ${message.message()}")
                        return true
                    }
                }
            }

            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (config?.debug == true) {
                        Log.d(TAG, "Bundle WebView loaded")
                    }
                }
            }
        }
    }

    private fun loadBundle() {
        Log.i(TAG, "=== loadBundle() START ===")
        scope.launch {
            try {
                val cfg = config
                if (cfg == null) {
                    Log.e(TAG, "loadBundle: config is null, aborting")
                    return@launch
                }

                val manager = bundleManager
                if (manager == null) {
                    Log.e(TAG, "loadBundle: bundleManager is null, aborting")
                    return@launch
                }

                Log.d(TAG, "loadBundle: Using BundleManager to load verified bundle...")

                // Use BundleManager to load verified bundle (OTA, cached, or fallback)
                val bundleJs = manager.loadBundle()

                if (bundleJs.isNullOrEmpty()) {
                    Log.e(TAG, "loadBundle: No bundle available (OTA, cached, or fallback), SDK will not work")
                    return@launch
                }

                Log.i(TAG, "loadBundle: Bundle loaded successfully (${bundleJs.length} chars)")

                val html = """
                    <!DOCTYPE html>
                    <html><head>
                        <meta charset="UTF-8">
                        <script>$bundleJs</script>
                    </head><body></body></html>
                """.trimIndent()

                // Use the configured RTB endpoint domain as base URL
                val baseUrl = cfg.rtbEndpoint.substringBeforeLast("/v1/")
                Log.d(TAG, "loadBundle: Loading bundle into WebView with baseUrl=$baseUrl")

                mainHandler.post {
                    Log.d(TAG, "loadBundle: WebView.loadDataWithBaseURL called")
                    bundleWebView?.loadDataWithBaseURL(
                        baseUrl,
                        html, "text/html", "UTF-8", null
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "loadBundle: Exception: ${e.message}", e)
            }
        }
        Log.i(TAG, "=== loadBundle() END (async) ===")
    }

    // Called by JsBridge when bundle is ready
    internal fun onBundleReady(version: String) {
        if (config?.debug == true) {
            Log.i(TAG, "OTA bundle ready: v$version")
        }

        // Mark bundle as healthy - clears crash detection marker
        bundleManager?.markBundleHealthy()

        isReady = true
        onReadyCallbacks.forEach { it() }
        onReadyCallbacks.clear()
    }

    // Called by Banner when it wants to load
    fun registerBanner(banner: Banner) {
        banners[banner.placementId] = banner
    }

    fun unregisterBanner(placementId: String) {
        banners.remove(placementId)
        pendingLoads.remove(placementId)
    }

    fun loadBannerAd(banner: Banner, callback: (Result<Unit>) -> Unit) {
        if (!isReady) {
            onReadyCallbacks.add { loadBannerAd(banner, callback) }
            return
        }

        val cfg = config ?: run {
            callback(Result.failure(HypeLabError.NotInitialized()))
            return
        }

        pendingLoads[banner.placementId] = callback

        // Escape all strings to prevent JS injection
        val escapedPlacementId = escapeJsString(banner.placementId)
        val escapedPlacementSlug = escapeJsString(banner.placementSlug)
        val escapedPropertySlug = escapeJsString(cfg.propertySlug)
        val escapedRtbEndpoint = escapeJsString(cfg.rtbEndpoint)

        // Call JS to load the banner
        val js = """
            (function() {
                if (typeof HypeLab !== 'undefined' && HypeLab._loadBanner) {
                    HypeLab._loadBanner('$escapedPlacementId', '$escapedPlacementSlug',
                        ${banner.size.width}, ${banner.size.height}, '$escapedPropertySlug', '$escapedRtbEndpoint');
                } else {
                    HypeLabBridge.log('error', 'HypeLab._loadBanner not available');
                }
            })();
        """.trimIndent()

        mainHandler.post {
            bundleWebView?.evaluateJavascript(js, null)
        }
    }

    // Called by JsBridge when JS reports banner loaded
    internal fun onBannerLoaded(placementId: String, width: Int, height: Int, adm: String, refreshIntervalMs: Long?) {
        val banner = banners[placementId] ?: return
        banner._onAdLoaded(width, height, adm, refreshIntervalMs)
        pendingLoads.remove(placementId)?.invoke(Result.success(Unit))
    }

    /**
     * Convert an error string from JS to a typed HypeLabError.
     */
    private fun parseErrorString(error: String): HypeLabError = when {
        error.contains("no fill", ignoreCase = true) -> HypeLabError.NoFill()
        error.contains("network", ignoreCase = true) -> HypeLabError.NetworkError()
        else -> HypeLabError.InternalError(error)
    }

    // Called by JsBridge when JS reports banner error
    internal fun onBannerError(placementId: String, error: String) {
        val banner = banners[placementId]
        val hypeLabError = parseErrorString(error)
        banner?._onAdError(hypeLabError)
        pendingLoads.remove(placementId)?.invoke(Result.failure(hypeLabError))
    }

    // Called by JsBridge when impression tracking completes
    internal fun onBannerImpression(placementId: String) {
        banners[placementId]?._onImpression()
    }

    // Called by JsBridge when click fires
    internal fun onBannerClick(placementId: String) {
        banners[placementId]?._onClick()
    }

    /**
     * Fire impression tracking via JS bundle.
     * Called by Banner when MRC viewability threshold is met.
     */
    fun fireImpression(placementId: String) {
        callJsFunction("_fireImpression", "'${escapeJsString(placementId)}'")
    }

    /**
     * Fire click tracking via JS bundle.
     * Called by Banner when user clicks the ad.
     */
    fun fireClick(placementId: String) {
        callJsFunction("_fireClick", "'${escapeJsString(placementId)}'")
    }

    /**
     * Notify JS bundle to destroy a banner handler.
     * Called when Banner.destroy() is invoked.
     */
    fun destroyBannerInJs(placementId: String) {
        callJsFunction("_destroyBanner", "'${escapeJsString(placementId)}'")
    }

    // Get the bridge for banner rendering operations
    internal fun getBridge(): JsBridge? = bridge

    internal fun getContext(): Context? = context

    internal fun getMainHandler(): Handler = mainHandler

    // =========================================================================
    // Native Ad Management
    // =========================================================================

    // Called by Native when it wants to register
    fun registerNative(native: Native) {
        natives[native.placementId] = native
    }

    fun unregisterNative(placementId: String) {
        natives.remove(placementId)
        pendingNativeLoads.remove(placementId)
    }

    fun loadNativeAd(native: Native, callback: (Result<Unit>) -> Unit) {
        if (!isReady) {
            onReadyCallbacks.add { loadNativeAd(native, callback) }
            return
        }

        val cfg = config ?: run {
            callback(Result.failure(HypeLabError.NotInitialized()))
            return
        }

        pendingNativeLoads[native.placementId] = callback

        // Escape all strings to prevent JS injection
        val escapedPlacementId = escapeJsString(native.placementId)
        val escapedPlacementSlug = escapeJsString(native.placementSlug)
        val escapedPropertySlug = escapeJsString(cfg.propertySlug)
        val escapedRtbEndpoint = escapeJsString(cfg.rtbEndpoint)

        // Call JS to load the native ad
        val js = """
            (function() {
                if (typeof HypeLab !== 'undefined' && HypeLab._loadNative) {
                    HypeLab._loadNative('$escapedPlacementId', '$escapedPlacementSlug',
                        '$escapedPropertySlug', '$escapedRtbEndpoint');
                } else {
                    HypeLabBridge.log('error', 'HypeLab._loadNative not available');
                }
            })();
        """.trimIndent()

        mainHandler.post {
            bundleWebView?.evaluateJavascript(js, null)
        }
    }

    // Called by JsBridge when JS reports native loaded
    internal fun onNativeLoaded(placementId: String, assetsJson: String) {
        val native = natives[placementId] ?: return
        native._onAdLoaded(assetsJson)
        pendingNativeLoads.remove(placementId)?.invoke(Result.success(Unit))
    }

    // Called by JsBridge when JS reports native error
    internal fun onNativeError(placementId: String, error: String) {
        val native = natives[placementId]
        val hypeLabError = parseErrorString(error)
        native?._onAdError(hypeLabError)
        pendingNativeLoads.remove(placementId)?.invoke(Result.failure(hypeLabError))
    }

    /**
     * Notify JS bundle to destroy a native handler.
     * Called when Native.destroy() is invoked.
     */
    fun destroyNativeInJs(placementId: String) {
        callJsFunction("_destroyNative", "'${escapeJsString(placementId)}'")
    }

    // =========================================================================
    // Interstitial Ad Management
    // =========================================================================

    // Called by Interstitial when it wants to register
    fun registerInterstitial(interstitial: Interstitial) {
        interstitials[interstitial.placementId] = interstitial
    }

    fun unregisterInterstitial(placementId: String) {
        interstitials.remove(placementId)
        fullscreenAdData.remove(placementId)
        pendingInterstitialLoads.remove(placementId)
    }

    fun loadInterstitialAd(interstitial: Interstitial, callback: (Result<Unit>) -> Unit) {
        if (!isReady) {
            onReadyCallbacks.add { loadInterstitialAd(interstitial, callback) }
            return
        }

        val cfg = config ?: run {
            callback(Result.failure(HypeLabError.NotInitialized()))
            return
        }

        pendingInterstitialLoads[interstitial.placementId] = callback

        // Escape all strings to prevent JS injection
        val escapedPlacementId = escapeJsString(interstitial.placementId)
        val escapedPlacementSlug = escapeJsString(interstitial.placementSlug)
        val escapedPropertySlug = escapeJsString(cfg.propertySlug)
        val escapedRtbEndpoint = escapeJsString(cfg.rtbEndpoint)

        // Call JS to load the interstitial
        val js = """
            (function() {
                if (typeof HypeLab !== 'undefined' && HypeLab._loadInterstitial) {
                    HypeLab._loadInterstitial('$escapedPlacementId', '$escapedPlacementSlug',
                        '$escapedPropertySlug', '$escapedRtbEndpoint');
                } else {
                    HypeLabBridge.log('error', 'HypeLab._loadInterstitial not available');
                }
            })();
        """.trimIndent()

        mainHandler.post {
            bundleWebView?.evaluateJavascript(js, null)
        }
    }

    // Called by JsBridge when JS reports interstitial loaded
    internal fun onInterstitialLoaded(placementId: String, adDataJson: String) {
        val interstitial = interstitials[placementId] ?: return

        try {
            // Parse as FullscreenAdData (unified format from JS bundle)
            val adData = FullscreenAdData.fromJson(adDataJson)

            // Cache for FullscreenActivity to retrieve
            fullscreenAdData[placementId] = adData

            interstitial._onAdLoaded(adData)
            pendingInterstitialLoads.remove(placementId)?.invoke(Result.success(Unit))
        } catch (e: Exception) {
            val error = HypeLabError.InvalidResponse("Failed to parse interstitial data: ${e.message}")
            interstitial._onAdError(error)
            pendingInterstitialLoads.remove(placementId)?.invoke(Result.failure(error))
        }
    }

    // Called by JsBridge when JS reports interstitial error
    internal fun onInterstitialError(placementId: String, error: String) {
        val interstitial = interstitials[placementId]
        val hypeLabError = parseErrorString(error)
        interstitial?._onAdError(hypeLabError)
        pendingInterstitialLoads.remove(placementId)?.invoke(Result.failure(hypeLabError))
    }

    /**
     * Fire interstitial impression tracking via JS bundle.
     * Called by FullscreenActivity when ad is displayed.
     */
    fun fireInterstitialImpression(placementId: String) {
        callJsFunction("_fireInterstitialImpression", "'${escapeJsString(placementId)}'")
        interstitials[placementId]?._onImpression()
    }

    /**
     * Fire interstitial click tracking via JS bundle.
     * Called by FullscreenActivity when user clicks the ad.
     */
    fun fireInterstitialClick(placementId: String) {
        callJsFunction("_fireInterstitialClick", "'${escapeJsString(placementId)}'")
        interstitials[placementId]?._onClick()
    }

    /**
     * Fire interstitial video event tracking via JS bundle.
     * Called by FullscreenActivity during video playback for VAST quartile events.
     */
    fun fireInterstitialVideoEvent(placementId: String, eventName: String, trackingUrl: String) {
        callJsFunction(
            "_fireInterstitialVideoEvent",
            "'${escapeJsString(placementId)}'",
            "'${escapeJsString(eventName)}'",
            "'${escapeJsString(trackingUrl)}'"
        )
    }

    /**
     * Called by FullscreenActivity when user closes an interstitial ad.
     */
    internal fun onInterstitialClose(placementId: String) {
        interstitials[placementId]?._onClose()
    }

    /**
     * Notify JS bundle to destroy an interstitial handler.
     * Called when Interstitial.destroy() is invoked.
     */
    fun destroyInterstitialInJs(placementId: String) {
        callJsFunction("_destroyInterstitial", "'${escapeJsString(placementId)}'")
    }

    /**
     * Cancel an in-progress interstitial load.
     * Called when Interstitial.cancel() is invoked.
     */
    fun cancelInterstitialLoad(placementId: String) {
        pendingInterstitialLoads.remove(placementId)
        callJsFunction("_cancelInterstitialLoad", "'${escapeJsString(placementId)}'")
    }

    // =========================================================================
    // Rewarded Ad Management
    // =========================================================================

    // Called by Rewarded when it wants to register
    fun registerRewarded(rewarded: Rewarded) {
        rewardeds[rewarded.placementId] = rewarded
    }

    fun unregisterRewarded(placementId: String) {
        rewardeds.remove(placementId)
        fullscreenAdData.remove(placementId)
        pendingRewardedLoads.remove(placementId)
    }

    fun loadRewardedAd(rewarded: Rewarded, callback: (Result<Unit>) -> Unit) {
        if (!isReady) {
            onReadyCallbacks.add { loadRewardedAd(rewarded, callback) }
            return
        }

        val cfg = config ?: run {
            callback(Result.failure(HypeLabError.NotInitialized()))
            return
        }

        pendingRewardedLoads[rewarded.placementId] = callback

        // Escape all strings to prevent JS injection
        val escapedPlacementId = escapeJsString(rewarded.placementId)
        val escapedPlacementSlug = escapeJsString(rewarded.placementSlug)
        val escapedPropertySlug = escapeJsString(cfg.propertySlug)
        val escapedRtbEndpoint = escapeJsString(cfg.rtbEndpoint)

        // Build SSV options JSON if present
        val ssvJson = rewarded.ssvOptions?.let { ssv ->
            val escapedUserId = escapeJsString(ssv.userID)
            val escapedCustomData = ssv.customData?.let { escapeJsString(it) }
            if (escapedCustomData != null) {
                """{"userID":"$escapedUserId","customData":"$escapedCustomData"}"""
            } else {
                """{"userID":"$escapedUserId"}"""
            }
        } ?: "null"

        // Call JS to load the rewarded ad
        val js = """
            (function() {
                if (typeof HypeLab !== 'undefined' && HypeLab._loadRewarded) {
                    HypeLab._loadRewarded('$escapedPlacementId', '$escapedPlacementSlug',
                        '$escapedPropertySlug', '$escapedRtbEndpoint', $ssvJson);
                } else {
                    HypeLabBridge.log('error', 'HypeLab._loadRewarded not available');
                }
            })();
        """.trimIndent()

        mainHandler.post {
            bundleWebView?.evaluateJavascript(js, null)
        }
    }

    // Called by JsBridge when JS reports rewarded loaded
    internal fun onRewardedLoaded(placementId: String, adDataJson: String) {
        val rewarded = rewardeds[placementId] ?: return

        try {
            // Parse as FullscreenAdData (unified format from JS bundle)
            val adData = FullscreenAdData.fromJson(adDataJson)

            // Cache for FullscreenActivity to retrieve
            fullscreenAdData[placementId] = adData

            rewarded._onAdLoaded(adData)
            pendingRewardedLoads.remove(placementId)?.invoke(Result.success(Unit))
        } catch (e: Exception) {
            val error = HypeLabError.InvalidResponse("Failed to parse rewarded data: ${e.message}")
            rewarded._onAdError(error)
            pendingRewardedLoads.remove(placementId)?.invoke(Result.failure(error))
        }
    }

    // Called by JsBridge when JS reports rewarded error
    internal fun onRewardedError(placementId: String, error: String) {
        val rewarded = rewardeds[placementId]
        val hypeLabError = parseErrorString(error)
        rewarded?._onAdError(hypeLabError)
        pendingRewardedLoads.remove(placementId)?.invoke(Result.failure(hypeLabError))
    }

    /**
     * Fire rewarded impression tracking via JS bundle.
     * Called by FullscreenActivity when ad is displayed.
     */
    fun fireRewardedImpression(placementId: String) {
        callJsFunction("_fireRewardedImpression", "'${escapeJsString(placementId)}'")
        rewardeds[placementId]?._onImpression()
    }

    /**
     * Fire rewarded click tracking via JS bundle.
     * Called by FullscreenActivity when user clicks the ad.
     */
    fun fireRewardedClick(placementId: String) {
        callJsFunction("_fireRewardedClick", "'${escapeJsString(placementId)}'")
        rewardeds[placementId]?._onClick()
    }

    /**
     * Fire rewarded video event tracking via JS bundle (VAST quartiles).
     * Called by FullscreenActivity during video playback.
     */
    fun fireRewardedVideoEvent(placementId: String, eventName: String, trackingUrl: String) {
        callJsFunction(
            "_fireRewardedVideoEvent",
            "'${escapeJsString(placementId)}'",
            "'${escapeJsString(eventName)}'",
            "'${escapeJsString(trackingUrl)}'"
        )
    }

    /**
     * Fire reward event to backend for SSV callback processing.
     * PRD Section 6: Server-Side Verification
     * Called by FullscreenActivity when user earns the reward.
     */
    fun fireRewardedReward(placementId: String) {
        callJsFunction("_fireRewardedReward", "'${escapeJsString(placementId)}'")
    }

    /**
     * Called by FullscreenActivity when video starts playing.
     */
    internal fun onRewardedVideoStart(placementId: String) {
        rewardeds[placementId]?._onVideoStart()
    }

    /**
     * Called by FullscreenActivity when video completes.
     */
    internal fun onRewardedVideoComplete(placementId: String) {
        rewardeds[placementId]?._onVideoComplete()
    }

    /**
     * Called by FullscreenActivity when video encounters an error.
     */
    internal fun onRewardedVideoError(placementId: String, error: String) {
        rewardeds[placementId]?._onVideoError(error)
    }

    /**
     * Called when reward is granted for a rewarded ad.
     * Delegates to unified fullscreen handler.
     */
    internal fun onRewardedRewardGranted(placementId: String) {
        onFullscreenRewardGranted(placementId)
    }

    /**
     * Called by FullscreenActivity when user closes the ad.
     */
    internal fun onRewardedClose(placementId: String) {
        rewardeds[placementId]?._onClose()
    }

    /**
     * Notify JS bundle to destroy a rewarded handler.
     * Called when Rewarded.destroy() is invoked.
     */
    fun destroyRewardedInJs(placementId: String) {
        callJsFunction("_destroyRewarded", "'${escapeJsString(placementId)}'")
    }

    /**
     * Cancel an in-progress rewarded load.
     * Called when Rewarded.cancel() is invoked.
     */
    fun cancelRewardedLoad(placementId: String) {
        pendingRewardedLoads.remove(placementId)
        callJsFunction("_cancelRewardedLoad", "'${escapeJsString(placementId)}'")
    }

    // =========================================================================
    // Unified Fullscreen Ad Management (FullscreenActivity)
    // =========================================================================

    /**
     * Get cached ad data for FullscreenActivity to retrieve.
     */
    fun getFullscreenAdData(placementId: String): FullscreenAdData? {
        return fullscreenAdData[placementId]
    }

    /**
     * Fire fullscreen impression tracking via JS bundle.
     * Called by FullscreenActivity when ad is displayed.
     */
    fun fireFullscreenImpression(placementId: String) {
        val adData = fullscreenAdData[placementId]

        // Route to appropriate handler based on ad mode
        if (adData?.isRewarded() == true) {
            fireRewardedImpression(placementId)
        } else {
            fireInterstitialImpression(placementId)
        }
    }

    /**
     * Fire fullscreen click tracking via JS bundle.
     * Called by FullscreenActivity when user clicks the ad.
     */
    fun fireFullscreenClick(placementId: String) {
        val adData = fullscreenAdData[placementId]

        // Route to appropriate handler based on ad mode
        if (adData?.isRewarded() == true) {
            fireRewardedClick(placementId)
        } else {
            fireInterstitialClick(placementId)
        }
    }

    /**
     * Fire fullscreen video event tracking via JS bundle (VAST quartiles).
     * Called by FullscreenActivity during video playback.
     */
    fun fireFullscreenVideoEvent(placementId: String, eventName: String, trackingUrl: String) {
        val adData = fullscreenAdData[placementId]

        // Route to appropriate handler based on ad mode
        if (adData?.isRewarded() == true) {
            fireRewardedVideoEvent(placementId, eventName, trackingUrl)
        } else {
            fireInterstitialVideoEvent(placementId, eventName, trackingUrl)
        }
    }

    /**
     * Called by FullscreenActivity when video starts playing.
     */
    internal fun onFullscreenVideoStart(placementId: String) {
        val adData = fullscreenAdData[placementId]
        if (adData?.isRewarded() == true) {
            rewardeds[placementId]?._onVideoStart()
        }
    }

    /**
     * Called by FullscreenActivity when video completes.
     */
    internal fun onFullscreenVideoComplete(placementId: String) {
        val adData = fullscreenAdData[placementId]
        if (adData?.isRewarded() == true) {
            rewardeds[placementId]?._onVideoComplete()
        }
    }

    /**
     * Called by FullscreenActivity when video encounters an error.
     */
    internal fun onFullscreenVideoError(placementId: String, error: String) {
        val adData = fullscreenAdData[placementId]
        if (adData?.isRewarded() == true) {
            rewardeds[placementId]?._onVideoError(error)
        }
    }

    /**
     * Called by FullscreenActivity when reward is granted.
     */
    internal fun onFullscreenRewardGranted(placementId: String) {
        val adData = fullscreenAdData[placementId]
        if (adData?.isRewarded() == true) {
            // Fire reward event to backend for SSV processing (PRD Section 6)
            fireRewardedReward(placementId)
            // Notify publisher callback
            rewardeds[placementId]?._onReward()
        }
    }

    /**
     * Called by FullscreenActivity when user closes the ad.
     */
    internal fun onFullscreenClose(placementId: String) {
        val adData = fullscreenAdData[placementId]

        // Route to appropriate handler based on ad mode
        if (adData?.isRewarded() == true) {
            rewardeds[placementId]?._onClose()
        } else {
            interstitials[placementId]?._onClose()
        }

        fullscreenAdData.remove(placementId)
    }

    /**
     * Called by FullscreenActivity when an error occurs.
     */
    internal fun onFullscreenError(placementId: String, error: String) {
        val adData = fullscreenAdData[placementId]
        val hypeLabError = HypeLabError.InternalError(error)

        // Route to appropriate handler based on ad mode
        if (adData?.isRewarded() == true) {
            rewardeds[placementId]?._onAdError(hypeLabError)
        } else {
            interstitials[placementId]?._onAdError(hypeLabError)
        }
    }

    // =========================================================================
    // Debug/Testing Utilities
    // =========================================================================

    /**
     * Clear the bundle cache and reset SDK state.
     * Forces re-download of bundle on next initialization.
     * For debugging/testing only.
     */
    fun clearBundleCache() {
        bundleManager?.clearCache()
        isReady = false
        Log.i(TAG, "Bundle cache cleared, SDK will re-download on next load")
    }
}
